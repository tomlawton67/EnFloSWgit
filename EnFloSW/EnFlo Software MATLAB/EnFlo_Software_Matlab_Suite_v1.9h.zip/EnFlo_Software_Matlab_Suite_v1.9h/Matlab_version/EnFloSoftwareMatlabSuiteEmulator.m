%%%%%%%%%%%%%%%%%%%%%%%%%%% Labview Emulator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc

addpath('Scripts\common');
inputSettings = tsvread('EnFloSoftwareMatlabSuiteSettings.xls');
commPort = inputSettings(5,1);
stringLength = inputSettings(5,2);

comm = tcpip('localhost', commPort, 'NetworkRole', 'client','Timeout', 300); %Open a connection as a client. 

fid = fopen('EmulatorLog.txt','w');
fprintf(fid,'-*-*-* EMULATOR LOG EnFlo Software Matlab Suite *-*-*-\r\n\r\n');
date = clock;
fprintf(fid,'                %02.0f/%02.0f/%02.0f %02.0f:%02.0f:%04.1f\r\n\r\n',date);
clear inputSettings commPort date
%% Call to 7HP
disp('-->7HP')
fprintf(fid,'-->7HP\r\n');
if exist('EnFloSoftwareMatlabSuiteEmulator\7HPexamples', 'dir')
    Ex7HPdir = dir('EnFloSoftwareMatlabSuiteEmulator\7HPexamples');
    Ex7HPnr = length(Ex7HPdir)-2;
    if Ex7HPnr == 0
        disp('No examples found.')
        fprintf(fid,'No examples found.\r\n\r\n');
    else
        for i = 1:Ex7HPnr
            disp(['Example ',num2str(i)])
            fprintf(fid,'Example %d\r\n',i);
            status = rmdir(['EnFloSoftwareMatlabSuiteEmulator\7HPexamples\',num2str(i),'\Output'],'s');
            status = mkdir(['EnFloSoftwareMatlabSuiteEmulator\7HPexamples\',num2str(i),'\Output']);
            status = rmdir('Output\7HP','s');
            status = mkdir('Output\7HP');
            status = rmdir('Input\7HP','s');
            status = mkdir('Input\7HP');
            status = copyfile(['EnFloSoftwareMatlabSuiteEmulator\7HPexamples\',num2str(i),'\Input\7HP\'],'Input\7HP\');
            Ex7HPdirn = dir('Input\7HP\');
            calibName = Ex7HPdirn(3).name;
            tic
            timerVal = tic;
            fopen(comm);
            outMsg = ['04;',calibName];
            for j = 1:97
                outMsg = sprintf('%s%s',outMsg,' ');
            end
            fwrite(comm,outMsg(1:100))
            
            inMsg = fread(comm, [1 100]);
            inMsg = char(inMsg);
            
            status = copyfile('Output\7HP\',['EnFloSoftwareMatlabSuiteEmulator\7HPexamples\',num2str(i),'\Output\7HP\']);
            fclose(comm);
            toc
            timerVal = toc;
            fprintf(fid,'Elapsed time is %2.1f seconds.\r\n',timerVal);
            if status == 1 && inMsg(4) == ' '
                fprintf(fid,'Completed with no error/warnings\r\n\r\n');
            else
                fprintf(fid,'%s\r\n\r\n',inMsg(4:end));
            end
        end
    end
    clear calibName Ex7HPdir Ex7HPdirn Ex7HPnr i inMsg j outMsg status timerVal ans
else
    disp('No Folder ''EnFloSoftwareMatlabSuiteEmulator/7HPexamples'' found.')
    fprintf(fid,'No folder ''EnFloSoftwareMatlabSuiteEmulator/7HPexamples'' found\r\n\r\n');
end

%% Call to 1D
disp('-->1D')
fprintf(fid,'-->1D\r\n');
if exist('EnFloSoftwareMatlabSuiteEmulator\1Dexamples', 'dir')
    Ex1Ddir = dir('EnFloSoftwareMatlabSuiteEmulator\1Dexamples');
    Ex1Dnr = length(Ex1Ddir)-2;
    if Ex1Dnr == 0
        disp('No examples found.')
        fprintf(fid,'No examples found.\r\n\r\n');
    else
        for i = 1:Ex1Dnr
            disp(['Example ',num2str(i)])
            fprintf(fid,'Example %d\r\n',i);
            status = rmdir(['EnFloSoftwareMatlabSuiteEmulator\1Dexamples\',num2str(i),'\Output'],'s');
            status = mkdir(['EnFloSoftwareMatlabSuiteEmulator\1Dexamples\',num2str(i),'\Output']);
            status = rmdir('Output\1D','s');
            status = mkdir('Output\1D');
            status = rmdir('Input\1D','s');
            status = mkdir('Input\1D');
            status = copyfile(['EnFloSoftwareMatlabSuiteEmulator\1Dexamples\',num2str(i),'\Input\1D\'],'Input\1D\');
            tic
            timerVal = tic;
            fopen(comm);
            outMsg = '01;';
            for j = 1:97
                outMsg = sprintf('%s%s',outMsg,' ');
            end
            fwrite(comm,outMsg(1:100))
            
            inMsg = fread(comm, [1 100]);
            inMsg = char(inMsg);
            status = copyfile('Output\1D\',['EnFloSoftwareMatlabSuiteEmulator\1Dexamples\',num2str(i),'\Output\1D\']);
            fclose(comm);
            toc
            timerVal = toc;
            fprintf(fid,'Elapsed time is %2.1f seconds.\r\n',timerVal);
            if status == 1 && inMsg(4) == ' '
                fprintf(fid,'Completed with no error/warnings\r\n\r\n');
            else
                fprintf(fid,'%s\r\n\r\n',inMsg(4:end));
            end
        end
    end
    clear Ex1Ddir Ex1Ddirn Ex1Dnr i inMsg j outMsg status timerVal ans
else
    disp('No Folder ''EnFloSoftwareMatlabSuiteEmulator/1Dexamples'' found.')
    fprintf(fid,'No folder ''EnFloSoftwareMatlabSuiteEmulator/1Dexamples'' found\r\n\r\n');
end

%% Call to 2D
disp('-->2D')
fprintf(fid,'-->2D\r\n');
if exist('EnFloSoftwareMatlabSuiteEmulator\2Dexamples', 'dir')
    Ex2Ddir = dir('EnFloSoftwareMatlabSuiteEmulator\2Dexamples');
    Ex2Dnr = length(Ex2Ddir)-2;
    if Ex2Dnr == 0
        disp('No examples found.')
        fprintf(fid,'No examples found.\r\n\r\n');
    else
        for i = 1:Ex2Dnr
            disp(['Example ',num2str(i)])
            fprintf(fid,'Example %d\r\n',i);
            status = rmdir(['EnFloSoftwareMatlabSuiteEmulator\2Dexamples\',num2str(i),'\Output'],'s');
            status = mkdir(['EnFloSoftwareMatlabSuiteEmulator\2Dexamples\',num2str(i),'\Output']);
            status = rmdir('Output\2D','s');
            status = mkdir('Output\2D');
            status = rmdir('Input\2D','s');
            status = mkdir('Input\2D');
            status = copyfile(['EnFloSoftwareMatlabSuiteEmulator\2Dexamples\',num2str(i),'\Input\2D\'],'Input\2D\');
            tic
            timerVal = tic;
            fopen(comm);
            outMsg = '02;';
            for j = 1:97
                outMsg = sprintf('%s%s',outMsg,' ');
            end
            fwrite(comm,outMsg(1:100))
            
            inMsg = fread(comm, [1 100]);
            inMsg = char(inMsg);
            status = copyfile('Output\2D\',['EnFloSoftwareMatlabSuiteEmulator\2Dexamples\',num2str(i),'\Output\2D\']);
            fclose(comm);
            toc
            timerVal = toc;
            fprintf(fid,'Elapsed time is %2.1f seconds.\r\n',timerVal);
            if status == 1 && inMsg(4) == ' '
                fprintf(fid,'Completed with no error/warnings\r\n\r\n');
            else
                fprintf(fid,'%s\r\n\r\n',inMsg(4:end));
            end
        end
    end
    clear Ex2Ddir Ex2Ddirn Ex2Dnr i inMsg j outMsg status timerVal ans
else
    disp('No Folder ''EnFloSoftwareMatlabSuiteEmulator/2Dexamples'' found.')
    fprintf(fid,'No folder ''EnFloSoftwareMatlabSuiteEmulator/2Dexamples'' found\r\n\r\n');
end

%% Call to LP
disp('-->LP')
fprintf(fid,'-->LP\r\n');
if exist('EnFloSoftwareMatlabSuiteEmulator\LPexamples', 'dir')
    ExLPdir = dir('EnFloSoftwareMatlabSuiteEmulator\LPexamples');
    ExLPnr = length(ExLPdir)-2;
    if ExLPnr == 0
        disp('No examples found.')
        fprintf(fid,'No examples found.\r\n\r\n');
    else
        for i = 1:ExLPnr
            disp(['Example ',num2str(i)])
            fprintf(fid,'Example %d\r\n',i);
            status = rmdir(['EnFloSoftwareMatlabSuiteEmulator\LPexamples\',num2str(i),'\Output'],'s');
            status = mkdir(['EnFloSoftwareMatlabSuiteEmulator\LPexamples\',num2str(i),'\Output']);
            status = rmdir('Output\LP','s');
            status = mkdir('Output\LP');
            status = rmdir('Input\LP','s');
            status = mkdir('Input\LP');
            status = copyfile(['EnFloSoftwareMatlabSuiteEmulator\LPexamples\',num2str(i),'\Input\LP\'],'Input\LP\');
            tic
            timerVal = tic;
            fopen(comm);
            outMsg = '03;';
            for j = 1:97
                outMsg = sprintf('%s%s',outMsg,' ');
            end
            fwrite(comm,outMsg(1:100))
            
            inMsg = fread(comm, [1 100]);
            inMsg = char(inMsg);
            status = copyfile('Output\LP\',['EnFloSoftwareMatlabSuiteEmulator\LPexamples\',num2str(i),'\Output\LP\']);
            fclose(comm);
            toc
            timerVal = toc;
            fprintf(fid,'Elapsed time is %2.1f seconds.\r\n',timerVal);
            if status == 1 && inMsg(4) == ' '
                fprintf(fid,'Completed with no error/warnings\r\n\r\n');
            else
                fprintf(fid,'%s\r\n\r\n',inMsg(4:end));
            end
        end
    end
    clear ExLPdir ExLPdirn ExLPnr i inMsg j outMsg status timerVal
else
    disp('No Folder ''EnFloSoftwareMatlabSuiteEmulator/LPexamples'' found.')
    fprintf(fid,'No folder ''EnFloSoftwareMatlabSuiteEmulator/LPexamples'' found\r\n\r\n');
end
fclose('all');
clear fid comm ans stringLength