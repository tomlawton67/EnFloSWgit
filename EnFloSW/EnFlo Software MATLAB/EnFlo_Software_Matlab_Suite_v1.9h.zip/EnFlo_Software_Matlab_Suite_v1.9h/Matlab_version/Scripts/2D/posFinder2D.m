function [pos, Qvector3D, Qvector2D, PNRotMat, RefPointCoord, RefArrowBaseCoord, RefArrowComponents, warningMsg] = posFinder2D(locIn, Qvector2D, Qvector3D, in, RefPointCoordIn, RefArrowBaseCoordIn, RefArrowComponents, nInputLine)
%planeFinder2D    Find the coefficients of the plane fitting the given
%                 points and apply proper translations and rotations to them 
%                 and to the vectorial quantities (if any).
%   [pos, Qvector3D, Qvector2D, PNRotMat, RefPointCoord, RefArrowBaseCoord, RefArrowComponents, warningMsg] = posFinder2D(locIn, Qvector2D, Qvector3D, in, RefPointCoordIn, RefArrowBaseCoordIn, RefArrowComponents, nInputLine)
%   finds the coefficients of equation of the plane (ax+by+cz=1) fitting the 
%   given points. Calculate the intersection vector between such plane and 
%   plane z=0 and apply translatation and rotation on the points coordinates. 
%   The outputs are a two column matrix "pos" with the two coordinates for 
%   each points laying on the plane, and the coefficients of the fitting plane 
%   a,b,c.

% $ Author: Davide Marucci
% $ Creation Date: 22/05/2019
% $ Last Update Date: 07/03/2021
% $ Version: 2.1g

%%
warningMsg = [];
[N2,P2] = planeFinder2D(locIn); %Find normal N2 to the plane fitting the given points, P2 is one of the points

if in.fFlipNormal(1) == 1
    N2 = -N2;
end

if in.fFlipNormal(2) == 1
    RefNormal = [0 0 -1];
else
    RefNormal = [0 0 1];
end

nrPointsInRange(1:4) = 0;
for iter = 1:5 %Iteration to change normals and ref normals
    loc = locIn;
    RefPointCoord = RefPointCoordIn;
    RefArrowBaseCoord = RefArrowBaseCoordIn;
    
    [P, N, check] = planeIntersect2D(RefNormal, [0 0 0], N2, P2); %N is the intercecting axis between plane 1 (xy) and 2, P is a point laying on axis N
    N = N/norm(N); %Intersection axis between plane 1 and 2 normalised
    if check == 0 || check == 1 %Plane parallel to plane xy
        pos = loc(:,1:2);
        RefPointCoord = RefPointCoord(1:2);
        RefArrowBaseCoord = RefArrowBaseCoord(1:2);
        rmat = [];
        loc(:,3) = loc(:,3) - mean(loc(:,3));
    else
        loc(end+1,:) =  RefPointCoord';
        loc(end+1,:) =  RefArrowBaseCoord';
        loc = loc - P;
        %Plane 1 equation a1*x+b1*y+c1*z+d1=0
        a1=0; b1=0; c1=1;%d1=0;
        %Plane 2 equation a2*x+b2*y+c2*z+d2=0
        a2 = N2(1); b2 = N2(2); c2 = N2(3);
        
        %Angle between plane 1 and 2: alpha
        cosalpha = abs(a1*a2+b1*b2+c1*c2)/(sqrt(a1^2+b1^2+c1^2)*sqrt(a2^2+b2^2+c2^2));
        c = cosalpha;
        s = sqrt(1-c^2);
        C = 1-c;
        x = N(1); y = N(2); z = N(3);
        rmat = [x^2*C+c    x*y*C-z*s  x*z*C+y*s;... %Rotation matrix around N-axis of angle alpha
            y*x*C+z*s  y^2*C+c    y*z*C-x*s;...
            z*x*C-y*s  z*y*C+x*s  z^2*C+c];
        locnew = loc;
        for i = 1:size(loc,1) %Apply the rotation matrix to the geometry
            locnew(i,1) = rmat(1,1)*loc(i,1) + rmat(1,2)*loc(i,2) + rmat(1,3)*loc(i,3);
            locnew(i,2) = rmat(2,1)*loc(i,1) + rmat(2,2)*loc(i,2) + rmat(2,3)*loc(i,3);
            locnew(i,3) = rmat(3,1)*loc(i,1) + rmat(3,2)*loc(i,2) + rmat(3,3)*loc(i,3);
        end
        loc = locnew;
        clear locnew
        
        angleXY = atand(N(2)/N(1));
        loc = rotateSTL(loc,'z',angleXY);
        pos = loc(1:end-2,1:2);
        RefPointCoord = loc(end-1,:)';
        RefArrowBaseCoord = loc(end,:)';
        loc = loc(1:end-2,:);
    end
    
    %In case fFlipNormal 2;2 and axis range is defined, if at least one of the plot points
    %location is outside the defined axis range, the code automatically try to flip the normals until all of them lie inside the range.
    %If no combination of normals which guarantee such condition can be found, then the first combination is chosen. 
    if in.fFlipNormal(1) == 2 && in.fFlipNormal(2) == 2 && ~isempty(in.fAxisLimX) && ~isempty(in.fAxisLimY) && iter < 5
        if min(pos(:,1))>=in.fAxisLimX(1) && max(pos(:,1))<=in.fAxisLimX(2) && min(pos(:,2))>=in.fAxisLimY(1) && max(pos(:,2))<=in.fAxisLimY(2)
            break
        end
        nrPointsInRange(iter) = pointsInRangeCounter2D(pos(:,1), pos(:,2), in.fAxisLimX, in.fAxisLimY);
        switch iter
            case 1 
                N2 = -N2;
            case 2
                N2 = -N2;
                RefNormal = [0 0 -1];
            case 3
                N2 = -N2;
            case 4 

                [maxNrPointsInRange, IDNrPointsInRange] = max(nrPointsInRange);
                switch IDNrPointsInRange
                    case 1
                        N2 = -N2;
                        RefNormal = [0 0 1];   
                    case 2
                        RefNormal = [0 0 1];
                    case 3
                        N2 = -N2;
                    case 4
                        break
                end
        end
    else 
        break
    end
end

if max(loc(:,3)) > 1
    warningMsg = ['Warning: in Data',num2str(nInputLine),'.xls points are not coplanar'];
end

%% Apply rotations to vectorial components (if any)
if in.fVectorComponentNr == 3 
    if in.fVectorRotations(3) ~= 0
        Qvector3D = rotateSTL(Qvector3D,'z',in.fVectorRotations(3));
    end
    if in.fVectorRotations(2) ~= 0
        Qvector3D = rotateSTL(Qvector3D,'y',in.fVectorRotations(2));
    end
    if in.fVectorRotations(1) ~= 0
        Qvector3D = rotateSTL(Qvector3D,'x',in.fVectorRotations(1));
    end
end

if in.fVectorComponentNr == 3 || (~isnan(sum(RefArrowComponents)) && isempty(Qvector2D))
    %Generate a 2D vector field from a 3D field in order to be plot in 2D
    %plotter streamlines and vectors. It also rotate the refArrow (if any).
    %N.B. refArrow is rotated only if rmat exists. In case
    %gGeometryPlanarPoints option is used to specify fitting plane, rmat
    %matrix is not created here and the reference arrow is not rotated
    %(hence its components has to be specified according to the fitting plane
    %reference system in that case)
    if ~isempty(rmat)
        QvectorOld = [Qvector3D; RefArrowComponents'];
        QvectorNew = QvectorOld;
        for i = 1:size(QvectorOld,1) %Apply the rotation matrix to the QvectorOld
            QvectorNew(i,1) = rmat(1,1)*QvectorOld(i,1) + rmat(1,2)*QvectorOld(i,2) + rmat(1,3)*QvectorOld(i,3);
            QvectorNew(i,2) = rmat(2,1)*QvectorOld(i,1) + rmat(2,2)*QvectorOld(i,2) + rmat(2,3)*QvectorOld(i,3);
            QvectorNew(i,3) = rmat(3,1)*QvectorOld(i,1) + rmat(3,2)*QvectorOld(i,2) + rmat(3,3)*QvectorOld(i,3);
        end
        Qvector2D = QvectorNew;
        clear QvectorNew QvectorOld
        Qvector2D = rotateSTL(Qvector2D,'z',angleXY);
        RefArrowComponents = Qvector2D(end,1:2);
        if in.fVectorComponentNr == 3
            Qvector2D = Qvector2D(1:end-1,1:2);     
        else
            Qvector2D = [];
        end
    end
end

PNRotMat.Point2 = P2;
PNRotMat.Normal2 = N2;
PNRotMat.IntersectionPoint = P;
PNRotMat.IntersectionAxis = N;
PNRotMat.check = check;
PNRotMat.rmat = rmat;
