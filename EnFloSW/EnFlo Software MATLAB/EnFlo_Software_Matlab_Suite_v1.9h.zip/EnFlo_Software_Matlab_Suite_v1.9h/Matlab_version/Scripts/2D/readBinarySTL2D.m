function triangles = readBinarySTL2D(filename)
%readBinarySTL2D    Read a binary stl file
%   triangles = readBinarySTL2D(filename)  %this function reads the binary 
%   stl file and gives out triangles as output to be processed by 
%   slice_stl_create_path function.

% $ Author: Sunil Bhandari
% $ Modified by: Davide Marucci
% $ Creation Date: 03/05/2018
% $ Last Update Date: 08/06/2019
% $ Version: 1.8

%% 
f = fopen(['Input\2D\Geometry\',filename],'r');
rd = fread(f,inf,'uint8=>uint8');
numTriangles = typecast(rd(81:84),'uint32');
triangles = zeros(numTriangles,12);
sh = reshape(rd(85:end),50,numTriangles);
tt = reshape(typecast(reshape(sh(1:48,1:numTriangles),1,48*numTriangles),'single'),12,numTriangles)';
triangles(:,1:9) = tt(:,4:12);
triangles(:,10:12) = tt(:,1:3);
fclose(f);