function multiPlotterSingleColorbar2D(in)
%multiPlotterSingleLegend2D    Produce a figure with only the colorbar visible  
%   multiPlotterSingleLegend2D(in)  produces a figure with only the colorbar
%   visible according to the settings provided in the structure "in"

% $ Author: Davide Marucci
% $ Creation Date: 05/04/2019
% $ Last Update Date: 07/07/2019
% $ Version: 1.8
%%
ax = axes('Units','Normal','Position',[0 0 1 1],'Visible','off'); %Set an invisible figure as large as the paper

contourf([10 11],[10 11],[0 1; 1 1])
colormap(in.cdColormap);
cbar = colorbar;
xlim([0 1]); ylim([0 1])

if strcmpi(in.mSingleColorbarOrientation,'Horizontal')
    cbar.Location = 'south';
end

set(cbar, 'Position', in.mSingleColorbarLocation)% To change size

ylabel(cbar,in.cdColorbarLabel,'interpreter',in.fInterpreterText);
% Define colorbar in case of logarithmic option 
if in.cdColorbarLogarithmic==1
    labelPos = log10(in.cdColorbarRange(1)):log10(in.cdColorbarRange(2));
    labelValue = 10.^labelPos; % Tick mark positions
    caxis([labelPos(1) labelPos(end)])
    set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
else   
    % Define colorbar in case of no logarithmic option
    caxis([in.cdColorbarRange(1) in.cdColorbarRange(2)])
end
set(gca,'visible','off')