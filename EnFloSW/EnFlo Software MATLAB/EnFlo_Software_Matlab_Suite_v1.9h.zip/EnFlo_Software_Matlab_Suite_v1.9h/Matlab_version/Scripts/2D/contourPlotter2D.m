function errorMsg = contourPlotter2D(pos, Q, in, nInputLine)
%contourPlotter    Produce a 2D contour graph  
%   contourPlotter(pos, Q, in, nInputLine)  outputs a 2D contour graph in which "pos" 
%   are the locations (X,Y) of the points (the order does not matter) and "Q"
%   is the value in each point. "in" is a structure containg the options
%   of the graph.

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 01/09/2019
% $ Version: 1.9
%%
errorMsg = [];
if isempty(Q)
    errorMsg = ['No data have been found for the contour plot of input line nr. ', num2str(nInputLine)];
    return
end
[Xplot,Yplot] = meshgrid(min(pos(:,1)):in.cdSpaceInterp:max(pos(:,1)), max(pos(:,2)):-in.cdSpaceInterp:min(pos(:,2))); %generate the mesh with the chosen resolution
Qplot_contour = griddata(pos(:,1),pos(:,2),Q(:,1),Xplot,Yplot,in.cdMethodInterp); %Calculate contour interpolation

Contour_extremes = in.cdColorbarRange;

if in.cWriteContourData == 1 %save a copy of Qplot_contour for writing the original contour file
    Qplot_contour_write = Qplot_contour; 
end

if in.cdColorbarLogarithmic == 1 %Modify data for logarithmic colorbar plot
    if min(min(Qplot_contour)) < 0
        errorMsg = ['When using a logarithmic scale for the colormap no negative values are allowed. Check input line nr. ',...
            num2str(nInputLine)];
        return
    end
    Qplot_contour = log10(Qplot_contour);
    if ~isempty(Contour_extremes)
        Contour_extremes = log10(Contour_extremes);
    end
end

if isempty(Contour_extremes)
    Contour_levels = linspace(min(min(Qplot_contour)),max(max(Qplot_contour)),in.cLevNr);
elseif ~isempty(Contour_extremes) && in.cIncludeMin == 0
    Contour_levels = linspace(Contour_extremes(1),Contour_extremes(2),in.cLevNr);
elseif ~isempty(Contour_extremes) && in.cIncludeMin == 1
    Contour_levels = [min(min(Qplot_contour)) linspace(Contour_extremes(1),Contour_extremes(2),in.cLevNr-1)];
end

[contValues, contProp] = contourf(Xplot(1,:),Yplot(:,1),Qplot_contour,Contour_levels); %produce contour plot
colormap(in.cdColormap);
contProp.LineStyle = in.cLineStyle;
cbar = colorbar;
ylabel(cbar,in.cdColorbarLabel,'interpreter',in.fInterpreterText);

% Define colorbar in case of logarithmic option and no range specified
if isempty(in.cdColorbarRange) && in.cdColorbarLogarithmic==1
    labelPos = linspace(min(min(Qplot_contour)),max(max(Qplot_contour)),5);
    labelValue = 10.^labelPos; % Tick mark positions
    caxis([labelPos(1) labelPos(end)])
    set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
    
% Define colorbar in case of logarithmic option and range specified
elseif ~isempty(in.cdColorbarRange)
    if in.cdColorbarLogarithmic==1
        labelPos = log10(in.cdColorbarRange(1)):log10(in.cdColorbarRange(2));
        labelValue = 10.^labelPos; % Tick mark positions
        caxis([labelPos(1) labelPos(end)])
        set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
    else
            
% Define colorbar in case of no logarithmic option and range specified
        caxis([in.cdColorbarRange(1) in.cdColorbarRange(2)])
    end
end

%% Write file with contour fitted data
if in.cWriteContourData == 1
    fid = fopen(['Output\2D\ContourData',num2str(nInputLine),'.xls'],'w');
    FirstRowText = 'Y/X';
    for i = 1:size(Xplot,2)
        FirstRowText = [FirstRowText,'\t%1.5g'];
    end
    FirstRowText = [FirstRowText,'\r\n'];
    if in.fReverseAxis(1)
        fprintf(fid,FirstRowText,-flip(Xplot(1,:)));
    else
        fprintf(fid,FirstRowText,Xplot(1,:));
    end
    FollowRowText = ['%1.5g',FirstRowText(4:end)];
    if ~in.fReverseAxis(2)
        for i = 1:size(Yplot,1)
            if in.fReverseAxis(1)
                fprintf(fid,FollowRowText,Yplot(i,1),flip(Qplot_contour_write(i,:)));
            else
                fprintf(fid,FollowRowText,Yplot(i,1),Qplot_contour_write(i,:));
            end
        end
    else
        for i = size(Yplot,1):-1:1
            if in.fReverseAxis(1)
                fprintf(fid,FollowRowText,-Yplot(i,1),flip(Qplot_contour_write(i,:)));
            else
                fprintf(fid,FollowRowText,-Yplot(i,1),Qplot_contour_write(i,:));
            end
        end
    end
    fclose(fid);
end