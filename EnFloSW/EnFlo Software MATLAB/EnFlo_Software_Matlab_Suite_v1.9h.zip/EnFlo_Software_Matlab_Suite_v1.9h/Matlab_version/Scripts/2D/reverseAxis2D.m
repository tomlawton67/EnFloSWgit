function reverseAxis2D(in, multi)
%reverseAxis2D    revese the axis of the figure
%   reverseAxis2D(in, multi)   reverse the axis of the figure. If
%   in.fReverseAxis(1) = 1 the x-axis is reversed, if in.fReverseAxis(2) =
%   1 the y-axis is reversed. The labels are changed accordingly (even 
%   though the data sign remains unaltered). multi == 1 if call is from
%   multiplotter, 0 otherwise

% $ Author: Davide Marucci
% $ Creation Date: 25/04/2019
% $ Last Update Date: 12/09/2021
% $ Version: 2.1d

%%
ax = gca;
if in.fReverseAxis(1)
    ax.XDir = 'reverse';
    if multi == 0 %Setting the manual tick appeared to be useful only for the interactive picture, not in the multiplot
        ax.XTickMode = 'manual';
        ax.XTickLabelMode = 'manual';
    end
    XTickLabel1 = str2double( ax.XTickLabel );
    XTickLabel1 = XTickLabel1(~isnan(XTickLabel1)); %Remove possible NaN values
    ax.XTick = XTickLabel1;
    XTickLabel1 = -XTickLabel1;
    XTickLabel1 = num2str( XTickLabel1 );
    ax.XTickLabel = XTickLabel1;
end
if in.fReverseAxis(2)
    ax.YDir = 'reverse';
    if multi == 0 %Setting the manual tick appeared to be useful only for the interactive picture, not in the multiplot
        ax.YTickMode = 'manual';
        ax.YTickLabelMode = 'manual';
    end
    YTickLabel1 = str2double( ax.YTickLabel );
    YTickLabel1 = YTickLabel1(~isnan(YTickLabel1)); %Remove possible NaN values
    ax.YTick = YTickLabel1;
    YTickLabel1 = -YTickLabel1;
    YTickLabel1 = num2str( YTickLabel1 );
    ax.YTickLabel = YTickLabel1;
end