function  [n, p] = planeFinder2D(X)
%planeFinder2D    Find normal to the plane fitting given points
%   [n, p] = planeFinder2D(X)  finds the normal and a point own by the
%   plane given points

% $ Author: Adrien Leygue
% $ Modified by: Davide Marucci
% $ Creation Date: 30/08/2013
% $ Last Update Date: 22/05/2019
% $ Version: 1.6

%%   
%the mean of the samples belongs to the plane
p = mean(X,1); %a point belonging to the plane

%The samples are reduced:
R = bsxfun(@minus,X,p);
%Computation of the principal directions if the samples cloud
[V,D] = eig(R'*R); %V is a 3 by 2 matrix. The columns of V form an orthonormal basis of the plane
%Extract the vector normal to the plane from the eigenvectors
n = V(:,1)'; %a unit (column) vector normal to the plane
   