function errorMsg = multiPlotter2D(in, figsNr, axisHandleList)
%multiPlotter2D    Produce and save multiplot files    
%   errorMsg = multiPlotter2D(in, figsNr, singleColorbarMode, axisHandleList)  
%   collects all the opened figures in Matlab environment and produces a subplot 
%   image with all of them. The image is then saved in the desired format. 
%   "in" is an array containg one structure with plotting options for each 
%   figure, "figsNr" is the number of figures. If in(1).mSingleColorbar = 1  
%   only the colorbar of the first graph is reproduced in a superimposed window 
%   at the specified locationshown.

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 20/02/2021
% $ Version: 2.1e
%%
errorMsg = [];
sub_pos = subplotPos(in(1).mPlotWidth,in(1).mPlotHeight,in(1).mLeftEdge,in(1).mRightEdge,in(1).mBottomEdge,...
    in(1).mTopEdge,in(1).mGraphsxColumn,in(1).mGraphsxRow,in(1).mSpaceX,in(1).mSpaceY);

%setting the Matlab figure
f2 = figure('visible','off');
clf(f2);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [in(1).mPlotWidth in(1).mPlotHeight]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 in(1).mPlotWidth in(1).mPlotHeight]);

[FigNr, FL] = unique(vertcat(in.fFigureNr),'last'); %FL is a vector with the lines of inputfile in which each figure appears for the first time

j = 1; %loop counter
for i = in(1).mGraphsxRow:-1:1 %iteration on the columns
    for ii = 1:in(1).mGraphsxColumn %iteration on the rows
        if j <= figsNr && j <= in(1).mGraphsxColumn*in(1).mGraphsxRow
            ax = axes('position',sub_pos{ii,i},'XGrid',in(FL(j)).fGrid(1),'XMinorGrid',in(FL(j)).fGridMinor(1),...
                'YGrid',in(FL(j)).fGrid(2),'YMinorGrid',in(FL(j)).fGridMinor(2),'FontSize',in(1).mFontSize,'Box','on','Layer','top');
            fig1 = get(axisHandleList{FL(j)},'children'); %get handle to all the children in the figure
            copyobj(fig1,ax); %copy children to new parent axes i.e. the subplot axes
            
            %%%%% set the colorbar limits %%%%
            % Define colorbar in case of logarithmic option and no range specified
            if in(FL(j)).cContourAct || in(FL(j)).cScatterAct || in(FL(j)).d3DAct
                colormap(gca,in(FL(j)).cdColormap);
                if isempty(in(FL(j)).cdColorbarRange) && in(FL(j)).cdColorbarLogarithmic==1
                    labelPos = linspace(min(min(fig1.ZData)),max(max(fig1.ZData)),5);
                    labelValue = 10.^labelPos; % Tick mark positions
                    caxis([labelPos(1) labelPos(end)])
                    % Define colorbar in case of logarithmic option and range specified
                elseif ~isempty(in(FL(j)).cdColorbarRange)
                    if in(FL(j)).cdColorbarLogarithmic==1
                        labelPos = log10(in(FL(j)).cdColorbarRange(1)):log10(in(FL(j)).cdColorbarRange(2));
                        labelValue = 10.^labelPos; % Tick mark positions
                        caxis([labelPos(1) labelPos(end)])
                    else
                        % Define colorbar in case of no logarithmic option and range specified
                        caxis([in(FL(j)).cdColorbarRange(1) in(FL(j)).cdColorbarRange(2)])
                    end
                end
            end
            if (max(vertcat(in.cContourAct)) || max(vertcat(in.cScatterAct)) || max(vertcat(in.d3DAct))) && ~in(1).mSingleColorbar
                %Plot colorbar
                if in(1).mSingleColorbar == 0
                    hC = colorbar;
                    if in(FL(j)).cdColorbarLogarithmic==1
                        set(hC,'Ytick',labelPos,'YTicklabel',labelValue);
                    end
                    ylabel(hC,in(FL(j)).cdColorbarLabel,'interpreter',in(FL(j)).fInterpreterText,'fontsize',in(1).mFontSize)
                end
                if ~in(FL(j)).cContourAct && ~in(FL(j)).cScatterAct && ~in(FL(j)).d3DAct
                    set(hC,'visible','off');
                end
            end
            
            if ~isempty(in(FL(j)).fTitle)
                title(in(FL(j)).fTitle,'interpreter',in(FL(j)).fInterpreterText,'fontsize',in(1).mFontSize)
            end
            clear labelPos labelValue
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Set axis settings
            if in(FL(j)).fLogAxis(1) == 1
                set(gca,'XScale','log');
            end
            if in(FL(j)).fLogAxis(2) == 1
                set(gca,'YScale','log');
            end
            
            if ~isempty(in(FL(j)).fAxisLimX)
                if in(FL(j)).fReverseAxis(1) %in case the reverse axis option is active the axis range is changed of sign and swapped
                    xlim([-in(FL(j)).fAxisLimX(2) -in(FL(j)).fAxisLimX(1)])
                else
                    xlim([in(FL(j)).fAxisLimX(1) in(FL(j)).fAxisLimX(2)])
                end
            end
            if ~isempty(in(FL(j)).fAxisLimY)
                if in(FL(j)).fReverseAxis(2) %in case the reverse axis option is active the axis range is changed of sign and swapped
                    ylim([-in(FL(j)).fAxisLimY(2) -in(FL(j)).fAxisLimY(1)])
                else
                    ylim([in(FL(j)).fAxisLimY(1) in(FL(j)).fAxisLimY(2)])
                end
            end
            %Reverse axis
            if in(FL(j)).fReverseAxis(1) == 1 || in(FL(j)).fReverseAxis(2) == 1
                reverseAxis2D(in(FL(j)),1)
            end
                 
            xlabel(in(FL(j)).fAxisLabelX,'interpreter',in(FL(j)).fInterpreterText,'fontsize',in(1).mFontSize)
            ylabel(in(FL(j)).fAxisLabelY,'interpreter',in(FL(j)).fInterpreterText,'fontsize',in(1).mFontSize)
            if in(FL(j)).fTickLabel(1) == 0
                set(gca,'XTickLabel',[],'TickLength',[0 0])
            end
            if in(FL(j)).fTickLabel(2) == 0
                set(gca,'YTickLabel',[],'TickLength',[0 0])
            end
            %Keep correct aspect ratio in graph
            if in(FL(j)).fKeepAspectRatio == 1 || in(FL(j)).lLocationAct || in(FL(j)).d3DAct
                set(gca,'DataAspectRatio',[1 1 1])
            end
            if in(FL(j)).lLocationAct || in(FL(j)).d3DAct
                set(gca,'ZGrid',in(FL(j)).fGrid(3),'ZMinorGrid',in(FL(j)).fGridMinor(3));
                
                if in(FL(j)).fLogAxis(3) == 1
                    set(gca,'ZScale','log');
                end
                
                zlabel(in(FL(j)).fAxisLabelZloc,'interpreter',in(FL(j)).fInterpreterText)
                
                if ~isempty(in(FL(j)).fAxisLimZloc)
                    zlim([in(FL(j)).fAxisLimZloc(1) in(FL(j)).fAxisLimZloc(2)])
                end
                
                if in(FL(j)).fTickLabel(3) == 0
                    set(gca,'ZTickLabel',[],'TickLength',[0 0])
                end
            end
            
            if ~isempty(in(FL(j)).ldViewAngles)
                view(in(FL(j)).ldViewAngles(1),in(FL(j)).ldViewAngles(2))
            end
        end
        j = j + 1;
    end
end

% Insert main title on top of multiplot
if ~isempty(in(1).mMainTitle)
    multiPlotMainTitle(in(1).mMainTitle, in(1).mInterpreterText, in(1).mMainTitleFontSize);
end

%Plot single colorbar
if in(1).mSingleColorbar == 1
    multiPlotterSingleColorbar2D(in(1))
end

%% Save image
set(gcf, 'Renderer', in(1).mFigRenderer)
switch in(1).mFormatFig
    case 'pdf'
        print(gcf, '-dpdf',['-',in(1).mResolution],'-loose','Output\2D\MultiImage.pdf');
    case 'emf'
        print(gcf, '-dmeta',['-',in(1).mResolution],'-loose','Output\2D\MultiImage.emf');
    case 'png'
        print(gcf, '-dpng',['-',in(1).mResolution],'-loose','Output\2D\MultiImage.png');
end

if figsNr > in(1).mGraphsxColumn*in(1).mGraphsxRow
    errorMsg = 'The number of figures to plot is larger than the specified number of slots, the exceding graphs have not been included in the multiplot';
end