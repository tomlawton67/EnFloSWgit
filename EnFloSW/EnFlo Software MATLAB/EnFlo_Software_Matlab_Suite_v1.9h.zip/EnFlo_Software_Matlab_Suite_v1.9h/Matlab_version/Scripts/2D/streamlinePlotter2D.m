function errorMsg = streamlinePlotter2D(pos, Qvector, in, nInputLine)
%streamlinePlotter    Produce a 2D scatter graph  
%   errorMsg = streamlinePlotter2D(pos, Q, in, nInputLine)  outputs a 2D streamline 
%   graph in which "pos" are the locations (X,Y) of the points (the order 
%   does not matter) and "Q" is the value in each point. "in" is a structure 
%   containg the options of the graph.

% $ Author: Davide Marucci
% $ Creation Date: 09/04/2019
% $ Last Update Date: 03/05/2020
% $ Version: 2.1
%%
errorMsg = [];
if isempty(Qvector)
    errorMsg = ['No data have been found for the streamline plot of input line nr. ', num2str(nInputLine)];
    return
end
[Xplot,Yplot] = meshgrid(min(pos(:,1)):in.cdSpaceInterp:max(pos(:,1)), max(pos(:,2)):-in.cdSpaceInterp:min(pos(:,2))); %generate the mesh with the chosen resolution

Q1plot_stream = griddata(pos(:,1),pos(:,2),Qvector(:,1),Xplot,Yplot,in.cdMethodInterp); %Calculate contour interpolation
Q2plot_stream = griddata(pos(:,1),pos(:,2),Qvector(:,2),Xplot,Yplot,in.cdMethodInterp);
h_strslc = streamslice(Xplot,Yplot,Q1plot_stream,Q2plot_stream,in.tStreamlineDensity,'linear',in.tShowArrows);
set(h_strslc,'color',in.tStreamlineColor,'LineWidth',in.tStreamlineWidth);
