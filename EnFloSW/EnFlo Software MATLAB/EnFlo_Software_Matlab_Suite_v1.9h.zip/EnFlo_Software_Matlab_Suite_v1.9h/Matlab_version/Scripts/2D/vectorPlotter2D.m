function errorMsg = vectorPlotter2D(pos, Qvector, in, nInputLine)
%vectorPlotter2D    Produce a 2D scatter graph  
%   errorMsg = vectorPlotter2D(pos, Q, in, nInputLine)  outputs a 2D vector graph in 
%   which "pos" are the locations (X,Y) of the points (the order does not matter) 
%   and "Q" is the value in each point. "in" is a structure containg the options
%   of the graph.

% $ Author: Davide Marucci
% $ Creation Date: 09/04/2019
% $ Last Update Date: 09/04/2019
% $ Version: 1.2
%%
errorMsg = [];
if isempty(Qvector)
    errorMsg = ['No data have been found for the vector plot of input line nr. ', num2str(nInputLine)];
    return
end
quiv = quiver(pos(:,1), pos(:,2), in.vVelMag*Qvector(:,1), in.vVelMag*Qvector(:,2));
quiv.LineWidth = in.vLineWidth;
quiv.Color = in.vColor;
quiv.AutoScale = in.vVectorAutoscale;
quiv.AutoScaleFactor = in.vVelMag;

