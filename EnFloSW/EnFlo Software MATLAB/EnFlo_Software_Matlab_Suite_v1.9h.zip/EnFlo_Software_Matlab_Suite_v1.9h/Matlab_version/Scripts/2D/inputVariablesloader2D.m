function [in, nInputLines, errorMsg] = inputVariablesloader2D(inputFileName)
%inputVariablesloader2D    load the input file variables    
%   [in, nInputLines, errorMsg] = inputVariablesloader2D(inputFileName)  create 
%   an array "in" containg the input variables with the desired plot settings 
%   from an input file.

% $ Author: Davide Marucci
% $ Creation Date: 08/04/2019
% $ Last Update Date: 03/05/2020
% $ Version: 2.1

%%
errorMsg = [];
[inputdata, fieldname, inputarray] = tsvread(inputFileName); %Read input file (inputdata is a matrix with only the numeric values, while text is shown as NaN
                                                           %fieldname is a string vector with the names taken from the first row of the input file)
                                                           %inputarray is an array with all the input entries considered as text
nInputLines = size(inputdata,1)-1;

%% Create variables structured as in from the file                                                           
in = cell(1,nInputLines);
inDefault = inputVarDefault2D; %Load default values for input variables

%Check if all the required input variables have been created
fieldnameDefault = fieldnames(inDefault);
errorMsg = inputVariablesChecker2D(fieldname, fieldnameDefault); 
if ~isempty(errorMsg)
    return
end

for j = 2:size(inputdata,1)
    for i = 1:length(fieldname)
        if ~iscell(inDefault.(fieldname{i})) %assign numerical quantity
            in{j-1}.(fieldname{i}) = inputdata(j,i);
        else %assign string quantity
            in{j-1}.(fieldname{i}) = inputarray{j,i};
            if strcmp(fieldname{i},'fAxisLimX') || strcmp(fieldname{i},'fAxisLimY') || strcmp(fieldname{i},'fLogAxis') || ...
                    strcmp(fieldname{i},'fGrid') || strcmp(fieldname{i},'fGridMinor') || strcmp(fieldname{i},'fTickLabel') || ...
                    strcmp(fieldname{i},'cdColorbarRange') || strcmp(fieldname{i},'mSingleColorbarLocation') || strcmp(fieldname{i},'gGeometryPlanarPoints') || ...
                    strcmp(fieldname{i},'gldGeometryTranslations') || strcmp(fieldname{i},'gldGeometryRotations') || strcmp(fieldname{i},'cdColormap') || ...
                    strcmp(fieldname{i},'fAxisLimZloc') || strcmp(fieldname{i},'ldListDatafileShown') || ...
                    strcmp(fieldname{i},'ldViewAngles') || strcmp(fieldname{i},'ldRefPointCoord') || ...
                    strcmp(fieldname{i},'ldRefArrowBaseCoord') || strcmp(fieldname{i},'ldRefArrowComponents') || strcmp(fieldname{i},'fFlipNormal') || ...
                    strcmp(fieldname{i},'fReverseAxis') || strcmp(fieldname{i},'fVectorRotations') || strcmp(fieldname{i},'dStreamlineStartPoint1') || ...
                    strcmp(fieldname{i},'dStreamlineStartPoint2')
                in{j-1}.(fieldname{i}) = eval(['[',in{j-1}.(fieldname{i}),']']);
            end
        end
    end
end

%Set same colorbar settings to all the others in case mSingleColorbar==1
if in{1}.mSingleColorbar == 1
    indexColorbar = 0;
    %Find in which input file row colorbar settings are defined
    for i=1:length(in)
        if ~isempty(in{i}.cdColorbarRange)
            indexColorbar = i;
            break
        end
    end
    if indexColorbar == 0
        errorMsg = 'For plotting a single colorbar in the multiplot the colormap range for the has to be defined (option cColorbarRange)';
        return
    end    
    names = fieldnames(in{indexColorbar});
    for i = 1:length(in)
        for j = 1:length(names)
            if strcmpi(names{j},'cdColormap') || strcmpi(names{j},'cLevNr') || strcmpi(names{j},'cdColorbarRange') || ...
                    strcmpi(names{j},'cdColorbarLogarithmic') || strcmpi(names{j},'fInterpreterText') || strcmpi(names{j},'cdColorbarLabel')
                in{i}.(names{j}) = in{indexColorbar}.(names{j});
            end
        end
    end
end

in = cell2mat(in);