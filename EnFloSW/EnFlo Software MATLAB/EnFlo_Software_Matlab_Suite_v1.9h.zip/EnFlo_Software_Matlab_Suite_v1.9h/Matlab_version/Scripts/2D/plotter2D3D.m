function [warningMsg, errorMsg] = plotter2D3D(pos, Q, Qvector3D, PNRotMat, loc, in, nInputLine)
%plotter2D3D    Create 3D graphs showing the 2D graphs inserted within
%               an stl geometry.
%   [warningMsg, errorMsg] = plotter2D3D(pos, Q, Qvector3D, PNRotMat, loc, in, nInputLine)
%   creates 3D graphs showing the 2D graphs inserted within an stl geometry.

% $ Author: Davide Marucci
% $ Creation Date: 29/05/2019
% $ Last Update Date: 26/02/2021
% $ Version: 2.1f
%%
errorMsg = [];
warningMsg = [];
%% Geometry loading and plot
if in(nInputLine).gGeometryAct
    TR = stlread(['Input\2D\Geometry\',in(nInputLine).gldGeometryFilename]);
    v = TR.Points;
    f = TR.ConnectivityList;
    v(:,[1 2 3]) = v(:,[1 2 3]) + in(nInputLine).gldGeometryTranslations';
    
    if in(nInputLine).gldGeometryRotations(3) ~= 0
        v = rotateSTL(v,'z',in(nInputLine).gldGeometryRotations(3));
    end
    if in(nInputLine).gldGeometryRotations(2) ~= 0
        v = rotateSTL(v,'y',in(nInputLine).gldGeometryRotations(2));
    end
    if in(nInputLine).gldGeometryRotations(1) ~= 0
        v = rotateSTL(v,'x',in(nInputLine).gldGeometryRotations(1));
    end
    
    field = 'faces';      value = {f};
    field2 = 'vertices';  value2 = {v};
    buildings = struct(field,value,field2,value2);
    
    patch(buildings,'FaceColor', in(nInputLine).gldFaceColor, 'EdgeColor', in(nInputLine).gldEdgeColor,'edgealpha',in(nInputLine).gldEdgeTransparency)
    if in(nInputLine).gldFaceTransparency < 1
        alpha(gca,in(nInputLine).gldFaceTransparency)
    end
    clear f v n field field2 value value2 buildings TR
end
%%

dataList = in(nInputLine).ldListDatafileShown;


if in(nInputLine).d3DAct
    for j = 1:length(dataList)
        %% Generate the meshgrid in the fitting plane and rotate and translate back the grid points to the original reference system
        if in(nInputLine).cContourAct
            Xpos = pos{dataList(j)}(:,1);
            Ypos = pos{dataList(j)}(:,2);
            
            [Xplot,Yplot] = meshgrid(min(Xpos):in(nInputLine).cdSpaceInterp:max(Xpos),...
                max(Ypos):-in(nInputLine).cdSpaceInterp:min(Ypos));
            Zplot = zeros(size(Xplot,1),size(Xplot,2));
            
            angleXY = atand(PNRotMat{j}.IntersectionAxis(2)/PNRotMat{j}.IntersectionAxis(1));
            rmatZ = [cosd(-angleXY), -sind(-angleXY), 0; sind(-angleXY), cosd(-angleXY),0; 0, 0,1];
            
            XplotNew = zeros(size(Xplot,1),size(Xplot,2));
            YplotNew = zeros(size(Yplot,1),size(Yplot,2));
            ZplotNew = zeros(size(Zplot,1),size(Zplot,2));
            
            if PNRotMat{j}.check~=0 && PNRotMat{j}.check~=1 %Namely if the fitting plane is neither parallel nor coincident with plane xy
                rmatTot = PNRotMat{j}.rmat\rmatZ';
                for ii = 1:size(XplotNew,1)
                    for jj = 1:size(XplotNew,2)
                        XplotNew(ii,jj) = rmatTot(1,1)*Xplot(ii,jj) + rmatTot(1,2)*Yplot(ii,jj) + rmatTot(1,3)*Zplot(ii,jj);
                        YplotNew(ii,jj) = rmatTot(2,1)*Xplot(ii,jj) + rmatTot(2,2)*Yplot(ii,jj) + rmatTot(2,3)*Zplot(ii,jj);
                        ZplotNew(ii,jj) = rmatTot(3,1)*Xplot(ii,jj) + rmatTot(3,2)*Yplot(ii,jj) + rmatTot(3,3)*Zplot(ii,jj);
                    end
                end
                XplotNew = XplotNew + PNRotMat{j}.IntersectionPoint(1);
                YplotNew = YplotNew + PNRotMat{j}.IntersectionPoint(2);
                ZplotNew = ZplotNew + PNRotMat{j}.IntersectionPoint(3);
            else
                XplotNew = Xplot;
                YplotNew = Yplot;
                ZplotNew(1:size(YplotNew,1),1:size(YplotNew,2)) = PNRotMat{j}.Point2(3);
            end
            
            
            %% Produce the countour plot
            if size(ZplotNew,1) == 1
                errorMsg = 'ContourPlot error - An issue with the contour plane rotation happened. Changing the values of flipNormal may fix the problem';
                return
            end
            Qplot_contour = griddata(Xpos,Ypos,Q{dataList(j)},Xplot,Yplot,in(nInputLine).cdMethodInterp); %Calculate contour interpolation

            if in(nInputLine).cdColorbarLogarithmic == 1 %Modify data for logarithmic colorbar plot
                if min(min(Qplot_contour)) < 0
                    errorMsg = ['ContourPlot error - when using a logarithmic scale for the colormap no negative values are allowed. Check input line nr. ',...
                        num2str(nInputLine)];
                    return
                end
                Qplot_contour = log10(Qplot_contour);
            end
            h = surf(XplotNew,YplotNew,ZplotNew,Qplot_contour, 'FaceAlpha',in(nInputLine).dContourTransparency);
            h.LineStyle = 'none';
        end
        %% Produce the scatter plot
        if in(nInputLine).cScatterAct
            Qplot_scatter = Q{dataList(j)};
            if in(nInputLine).cdColorbarLogarithmic == 1 %Modify data for logarithmic colorbar plot
                if min(min(Qplot_scatter)) < 0
                    errorMsg = ['ScatterPlot error - when using a logarithmic scale for the colormap no negative values are allowed. Check input line nr. ',...
                        num2str(nInputLine)];
                    return
                end
                Qplot_scatter = log10(Qplot_scatter);
            end
            s = scatter3(loc{dataList(j)}(:,1),loc{dataList(j)}(:,2),loc{dataList(j)}(:,3), in(nInputLine).cScatterPointSize, Qplot_scatter,'filled'); %produce scatter plot
            s.MarkerEdgeColor = 'k';
        end
        
        %% Common to contour and scatter plot
        if in(nInputLine).cContourAct || in(nInputLine).cScatterAct
            colormap(in(nInputLine).cdColormap);
            cbar = colorbar;
            ylabel(cbar,in(nInputLine).cdColorbarLabel,'interpreter',in(nInputLine).fInterpreterText);
            % Define colorbar in case of logarithmic option and no range specified
            if isempty(in(nInputLine).cdColorbarRange) && in(nInputLine).cdColorbarLogarithmic==1
                %Find minimum and maximum of dataset
                if in(nInputLine).cContourAct && ~in(nInputLine).cScatterAct
                    labelPos = linspace(min(min(Qplot_contour)),max(max(Qplot_contour)),5);
                elseif ~in(nInputLine).cContourAct && in(nInputLine).cScatterAct
                    labelPos = linspace(min(Qplot_scatter),max(Qplot_scatter),5);
                else
                    labelPos = linspace(min([min(min(Qplot_contour)) min(Qplot_scatter)]),...
                        max([max(max(Qplot_contour)) max(Qplot_scatter)]),5);
                end
                labelValue = 10.^labelPos; % Tick mark positions
                caxis([labelPos(1) labelPos(end)])
                set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
                
                % Define colorbar in case of logarithmic option and range specified
            elseif ~isempty(in(nInputLine).cdColorbarRange)
                if in(nInputLine).cdColorbarLogarithmic==1
                    labelPos = log10(in(nInputLine).cdColorbarRange(1)):log10(in(nInputLine).cdColorbarRange(2));
                    labelValue = 10.^labelPos; % Tick mark positions
                    caxis([labelPos(1) labelPos(end)])
                    set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
                else
                    % Define colorbar in case of no logarithmic option and range specified
                    caxis([in(nInputLine).cdColorbarRange(1) in(nInputLine).cdColorbarRange(2)])
                end
            end
        end
        
        %% Produce the streamline plot
        if in(nInputLine).tStreamlineAct
            if in(j).fVectorComponentNr==3
                Xstream = loc{dataList(j)}(:,1);
                Ystream = loc{dataList(j)}(:,2);
                Zstream = loc{dataList(j)}(:,3);
                % Create a fake volume around the measuring plane, by
                % translating the plane 10 measuring unites up and
                % down. The fake volume is needed to interpolate the 3D
                % streamlines in the space
                XstreamPlus = Xstream + 10*PNRotMat{j}.Normal2(1);
                YstreamPlus = Ystream + 10*PNRotMat{j}.Normal2(2);
                ZstreamPlus = Zstream + 10*PNRotMat{j}.Normal2(3);
                XstreamMinus = Xstream - 10*PNRotMat{j}.Normal2(1);
                YstreamMinus = Ystream - 10*PNRotMat{j}.Normal2(2);
                ZstreamMinus = Zstream - 10*PNRotMat{j}.Normal2(3);
                XstreamAll = [XstreamMinus; Xstream; XstreamPlus];
                YstreamAll = [YstreamMinus; Ystream; YstreamPlus];
                ZstreamAll = [ZstreamMinus; Zstream; ZstreamPlus];
                
                [Xstream3D, Ystream3D, Zstream3D] = meshgrid(min(XstreamAll):in(nInputLine).cdSpaceInterp:max(XstreamAll),...
                    min(YstreamAll):in(nInputLine).cdSpaceInterp:max(YstreamAll),...
                    min(ZstreamAll):in(nInputLine).cdSpaceInterp:max(ZstreamAll));
                
                %Remove component out of the fitting plane from vectorial quantity
                Qstream = [Qvector3D{dataList(j)}(:,1) Qvector3D{dataList(j)}(:,2) Qvector3D{dataList(j)}(:,3)];
                if in(j).fFlipNormal(1)
                    Qstream = Qstream + Qstream.*PNRotMat{j}.Normal2;
                else
                    Qstream = Qstream - Qstream.*PNRotMat{j}.Normal2;
                end
                
                Q1streamAll = [Qstream(:,1); Qstream(:,1); Qstream(:,1)];
                Q2streamAll = [Qstream(:,2); Qstream(:,2); Qstream(:,2)];
                Q3streamAll = [Qstream(:,3); Qstream(:,3); Qstream(:,3)];
                
                Q1plot_stream3D = griddata(XstreamAll,YstreamAll,ZstreamAll,Q1streamAll,Xstream3D,Ystream3D,Zstream3D);
                Q2plot_stream3D = griddata(XstreamAll,YstreamAll,ZstreamAll,Q2streamAll,Xstream3D,Ystream3D,Zstream3D);
                Q3plot_stream3D = griddata(XstreamAll,YstreamAll,ZstreamAll,Q3streamAll,Xstream3D,Ystream3D,Zstream3D);
                
                if in(nInputLine).dStreamlineSlice == 1 %Plot with streamline command
                    if ~isempty(in(nInputLine).dStreamlineStartPoint1) && ~isempty(in(nInputLine).dStreamlineStartPoint2)
                        point1 = in(nInputLine).dStreamlineStartPoint1;
                        point2 = in(nInputLine).dStreamlineStartPoint2;
                        pointNr = round(sqrt((point1(1)-point2(1))^2 + (point1(2)-point2(2))^2 + (point1(3)-point2(3))^2)/in(nInputLine).tStreamlineDensity);
                    else
                        errorMsg = 'No dStreamlineStartPoint specified';
                        return
                    end
                    
                    startx = linspace(point1(1), point2(1), pointNr);
                    starty = linspace(point1(2), point2(2), pointNr);
                    startz = linspace(point1(3), point2(3), pointNr);
                    
                    h_stream = streamline(Xstream3D,Ystream3D,Zstream3D,Q1plot_stream3D,Q2plot_stream3D,Q3plot_stream3D,startx,starty,startz);
                    
                elseif in(nInputLine).dStreamlineSlice == 2 %Plot with streamslice command
                    
                    if (PNRotMat{j}.Normal2(1) == 1 && PNRotMat{j}.Normal2(2) == 0 && PNRotMat{j}.Normal2(3) == 0) || ...
                       (PNRotMat{j}.Normal2(1) == 0 && PNRotMat{j}.Normal2(2) == 1 && PNRotMat{j}.Normal2(3) == 0) || ...
                       (PNRotMat{j}.Normal2(1) == 0 && PNRotMat{j}.Normal2(2) == 0 && PNRotMat{j}.Normal2(3) == 1)
                        startx = PNRotMat{j}.Point2(1)*PNRotMat{j}.Normal2(1); 
                        starty = PNRotMat{j}.Point2(2)*PNRotMat{j}.Normal2(2); 
                        startz = PNRotMat{j}.Point2(3)*PNRotMat{j}.Normal2(3);
                    else
                        errorMsg = 'Streamslice have been requested but the fitting plane is not perpendicular to any of the plot axes. Try using streamline instead';
                        return
                    end

                    
                    h_stream = streamslice(Xstream3D,Ystream3D,Zstream3D,Q1plot_stream3D,Q2plot_stream3D,Q3plot_stream3D,startx,starty,startz,...
                        in(nInputLine).tStreamlineDensity,'linear',in(nInputLine).tShowArrows);                    
                end
                set(h_stream,'color',in(nInputLine).tStreamlineColor,'LineWidth',in(nInputLine).tStreamlineWidth);
                
            else
                warningMsg = 'A streamline plot was requested for the 3Dplotter but fVectorComponentNr is not set to 3';
            end
        end

        
        %% Produce the vector plot
        if in(nInputLine).vVectorAct
            if in(j).fVectorComponentNr==3
                quiv = quiver3(loc{dataList(j)}(:,1),loc{dataList(j)}(:,2),loc{dataList(j)}(:,3),...
                    in(nInputLine).vVelMag*Qvector3D{dataList(j)}(:,1),in(nInputLine).vVelMag*Qvector3D{dataList(j)}(:,2),...
                    in(nInputLine).vVelMag*Qvector3D{dataList(j)}(:,3));
                quiv.LineWidth = in(nInputLine).vLineWidth;
                quiv.Color = in(nInputLine).vColor;
                quiv.AutoScale = in(nInputLine).vVectorAutoscale;
                quiv.AutoScaleFactor = in(nInputLine).vVelMag;
            else
                warningMsg = 'A vector plot was requested for the 3Dplotter but fVectorComponentNr is not set to 3';
            end
        end
        
        clear angleXY cbar h h_stream Q1plot_stream3D Q1streamAll Q2plot_stream3D ...
            Q2streamAll Q3plot_stream3D Q3streamAll Qplot_contour Qstream rmatZ startx starty startz Xplot XplotNew ...
            Xpos Xstream Xstream3D XstreamAll XstreamMinus XstreamPlus Yplot YplotNew Ypos Ystream Ystream3D YstreamAll YstreamMinus ...
            YstreamPlus Zplot ZplotNew Zstream Zstream3D ZstreamAll ZstreamMinus ZstreamPlus        
    end

end

%% Plot Measuring points
if in(nInputLine).lLocationAct
    for i = 1:length(dataList)
        plotHandle = plot3(loc{dataList(i)}(:,1),loc{dataList(i)}(:,2),loc{dataList(i)}(:,3));
        set(plotHandle,'linestyle','none','Marker',in(nInputLine).lMarkerType,...
            'MarkerSize',in(nInputLine).lMarkerSize,'color',in(nInputLine).lMarkerColor);
    end
end


%% Plot reference point (if any)
if ~isempty(in(nInputLine).ldRefPointCoord) && ~isempty(in(nInputLine).ldRefPointSize) && ~isempty(in(nInputLine).ldRefPointColor)
    scatter3(in(nInputLine).ldRefPointCoord(1),in(nInputLine).ldRefPointCoord(2),in(nInputLine).ldRefPointCoord(3),...
        in(nInputLine).ldRefPointSize,in(nInputLine).ldRefPointColor,'p','filled','MarkerEdgeColor','k');
end

%% Plot reference vector (if any)
if ~isempty(in(nInputLine).ldRefArrowBaseCoord) && ~isempty(in(nInputLine).ldRefArrowComponents) && ~isempty(in(nInputLine).ldRefArrowSize) && ...
        ~isempty(in(nInputLine).ldRefArrowColor)
    quiver3(in(nInputLine).ldRefArrowBaseCoord(1),in(nInputLine).ldRefArrowBaseCoord(2),in(nInputLine).ldRefArrowBaseCoord(3),...
        in(nInputLine).ldRefArrowComponents(1),in(nInputLine).ldRefArrowComponents(2),in(nInputLine).ldRefArrowComponents(3),...
        'MaxHeadSize',in(nInputLine).ldRefArrowSize,'LineWidth',in(nInputLine).ldRefArrowSize,'color',in(nInputLine).ldRefArrowColor);
end
