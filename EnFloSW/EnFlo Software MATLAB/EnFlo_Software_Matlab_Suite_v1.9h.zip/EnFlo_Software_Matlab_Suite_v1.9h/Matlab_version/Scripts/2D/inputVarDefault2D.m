function inDefault = inputVarDefault2D
%inputVarDefault2D    load the required variables names and format    
%   inDefault = inputVarDefault2D  This function lists all the possible input 
%   entry which must be specified in the Input2D.xls file. When needed an 
%   explanation of the variable function is added. Only the variable name 
%   after the dot (hence excluding inDefault.) has to be indicated as header 
%   of the input file columns. The parenteses after the equal indicates if
%   the variable is expected to be a number [] or a string {}.

% $ Author: Davide Marucci
% $ Creation Date: 10/04/2019
% $ Last Update Date: 03/05/2020
% $ Version: 2.1

%% Figure settings
inDefault.fFigureNr = [];
inDefault.fAxisLabelX = {};
inDefault.fAxisLabelY = {};
inDefault.fAxisLabelZloc = {}; %Set z label in locationPlotter and 2D3Dplotter
inDefault.fTitle = {};
inDefault.fAxisLimX = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimY = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimZloc = {}; %[Min;Max] set z range in locationPlotter and 2D3Dplotter, works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fLogAxis = {}; %[x-axis;y-axis;z-axis] logarithmic axes. 0: linear, 1: log
inDefault.fInterpreterText = {}; % ['latex','none']
inDefault.fShowFigure = []; %Show figure in interactive window [0,1]
inDefault.fKeepAspectRatio = []; %Keep costant scaling in figure axes [0,1]
inDefault.fGrid = {}; %[x-axis;y-axis;z-axis] Show axis grid in figure (0,1)
inDefault.fGridMinor = {}; %[x-axis;y-axis;z-axis] Show axis minor grid in figure (0,1)
inDefault.fTickLabel = {}; %[x-axis;y-axis;z-axis] Show axis tick labels (0,1)
inDefault.fFontSize = [];
inDefault.fPlotOrder = []; %define the order of the layers plot in each figure. 
                           %Each digit indicate a different plot and the number define their order [e.g. 12345]
                           %1.contour, 2.scatter, 3.streamlines, 4.vectors, 5.geometry
inDefault.fFlipNormal = {}; %(flipNormalFittingPlane;flipNormalRefPlane) Since any plane can have two normals (same direction but opposite sign), 
%sometime the figure can appear upside down or with left and right side swapped. Activating the flipping 
%allow to view it correctly, by manually changing the sign of either the
%normal to the fitting plane or to the reference plane (xy). If (2;2) the
%flipping is executed automatically in all the four possible combinations until all the points lie in the requested
%range (fAxisLimX and fAxisLimY must be specified).
inDefault.fReverseAxis = {}; %(reverseXaxis, reverseYaxis) Reverse the figure axes, to be used in conjuction with flipnormal to obtain the desired axes orientation. N.B. it reverses the axis by changing its orientation (hence negative towards right, instead of left). 
%At the same time the axis labels are changed of sign accordingly (while the data remain unaltered)
inDefault.fVectorComponentNr = []; %0 If no vectorial quantities are going to be loaded in the data file (7th, 8th and 9th column are empty)
                                   %2 if only two components of the vector quantity are going to be indicated in the 7th and 8th column of data file
                                   %3 if all the three components of the vector quantity are going to be indicated in the 7th, 8th and 9th column of data file
inDefault.fVectorRotations = {};% (angleX;angleY;angleZ) angles (in degrees) of rotation to align the vectorial quantities (e.g. velocity) with the measuring reference system. The rotation will be done in the order around axis Z, Y and as last X
                                % To be used in case e.g. the LDA is not align with the model coordinate system and streamlines or velocity vectors want to be plotted
%% Contour and scatter plot settings (1 and 2 in fplotOrder)
inDefault.cContourAct = []; % Activate contourPlotter [0,1] N.B. It is used also to activate the contourplot in 2D3D plotter
inDefault.cScatterAct = []; % Activate scatterPlotter [0,1]
inDefault.cWriteContourData = []; % Activate contour data file writing [0,1]
inDefault.cdColormap = {}; %Colormap style. It can be a Matlab predefined style (e.g. 'parula','jet',etc.), or a user made one (e.g. [1 1 1;0.6 0.6 0.6; 0.4 0.4 0.4; 0 0 0] for a grey scale, colors are given in RGB format)
inDefault.cdMethodInterp = {}; %['nearest','linear','cubic','natural','v4'] (it affects also streamlines)
inDefault.cdSpaceInterp = []; %Interpolation grid distance (it affects also streamline interpolation grid, but not density)
inDefault.cLevNr = []; %Number of levels in colorbar
inDefault.cIncludeMin = []; %[0,1] %0 if cdColorbarRange is specified, colormap levels are spaced according to cdColorbarRange (and kept the same for each graph)
                                   %1 same as 0 but including minimum value before cdColorbarRange(1) in order not to have white patches if min is not inside range     
inDefault.cdColorbarLabel = {};
inDefault.cdColorbarRange = {}; %[Min;Max] works only if both Min and Max are specified, otherwise the range is decided automatically from the min to the max of each graph
inDefault.cdColorbarLogarithmic = []; %[0,1] note: logarithmic scale cannot accept negative values
inDefault.cScatterPointSize = [];
inDefault.cLineStyle = {}; %['-','--',':','-.','none'] Contour line style

%% Strealines plot settings (3 in fplotOrder)
inDefault.tStreamlineAct = []; % Activate streamlinesPlotter [0,1]
inDefault.tStreamlineDensity = []; %Density of streamlines [e.g. 1]
%inDefault.cdSpaceInterp = []; %Modified from Contour settings
%inDefault.cdMethodInterp = {}; %Modified from Contour settings
inDefault.tStreamlineColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.tStreamlineWidth = [];
inDefault.tShowArrows = {}; %['arrows', 'noarrows'] Show arrows on streamline

%% Vectors plot settings (4 in fplotOrder)
inDefault.vVectorAct = []; % Activate vectorsPlotter [0,1]
inDefault.vVectorAutoscale = {}; %['off','on'] Autoscale vectors automatically to fit into the figure 
inDefault.vVelMag = []; %Magnification factor for vectors, if 1 no magnification (used only if vVectorAutoscale is off)
inDefault.vLineWidth = [];
inDefault.vColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal

%% Geometry plot settings (5 in fplotOrder) N.B. Some variables are shared with the location and 2D3D ploter (marked as gld)
inDefault.gGeometryAct = []; %Activate geometryPlotter [0,1] N.B. It is used also to activate the geometry in 2D3D plotter and locationPlotter
inDefault.gldGeometryFilename = {}; %e.g. Geometry1.stl. N.B. Geometry must be in STL format (locationPlotter and 2D3D plotter accept both ASCII and binary STL format while for the section slicing only the binary is accepted)
inDefault.gldGeometryTranslations = {};% (X;Y;Z) Translation which must be apply to the stl geometry to align its origin with the plot data origin
inDefault.gldGeometryRotations = {};% (angleX;angleY;angleZ) angles (in degrees) of rotation to align the stl geometry  with the measuring reference system. The rotation will be done in the order around axis Z, Y and as last X
inDefault.gGeometryPlanarPoints = {}; %Three non colinear points laying on the desired plotting plane (e.g. [0 -100 100;0 -100 0;100 -100 0]). This variable can be used to force the selection of the slicing plane to be different from the real one
inDefault.gGeometryOversizeMargin = []; %(e.g. 0.1 for 10% of axes range) When the range of the plot is chosen (by using fAxisLimX,Y,Z) the stl points of the geometry outside this range are automatically excluded to save time in making the slice. 
                                        %However, if a geometric element extends from inside to outside this range, the latter may not be correctly shown. To overcome this issue a value here can be specified as a percentage of the range in which the stl points will still be included. 
inDefault.gldFaceColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.gldEdgeColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.gldFaceTransparency = []; %Face surface transparency value from 0 to 1 (where 0 is invisible)
inDefault.gldEdgeTransparency = []; %Edge transparency value from 0 to 1 (where 0 is invisible)

%% Location plot settings N.B. Some variables are shared with the 2D3D plotter (marked as ld)
inDefault.lLocationAct = []; %Activate locationPlotter [0,1]
inDefault.ldListDatafileShown = {}; %(DataNr1;DataNr2;...)List of datafile nr. whose points are shown in the location plotter
inDefault.ldViewAngles = {}; %(az;el) Set the viewing angles for the figure in degrees (azimuth and elevation angles)
inDefault.lMarkerType = {};
inDefault.lMarkerColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lMarkerSize = [];
inDefault.ldRefPointCoord = {}; %(x;y;z) Coordinates of reference point (e.g. source location) (leave blank if not needed)
inDefault.ldRefPointColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.ldRefPointSize = []; % e.g. 20 (leave blank if not needed)
inDefault.ldRefArrowBaseCoord = {}; %(x;y;z) Coordinates of reference arrow base point (e.g. wind direction) (leave blank if not needed)
inDefault.ldRefArrowComponents = {}; %(x;y;z) Lengths of reference arrow in each direction (leave blank if not needed)
inDefault.ldRefArrowColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.ldRefArrowSize = []; % (e.g. 2) Specify the arrow line width and head size (leave blank if not needed)

%% 2D3Dplotter 
inDefault.d3DAct = []; %Activate 2D3D plotter [0,1] N.B. Used in conjuction with gGeometryAct and cContourAct
inDefault.dContourTransparency = []; %Contour transparency value from 0 to 1 (where 0 is invisible)
inDefault.dStreamlineSlice = []; %Choose between: 1 for streamline, 2 for streamslice (Streamslice possible only for plane perpendicular to one reference axis - either x, y or z)
inDefault.dStreamlineStartPoint1 = {}; %(X;Y;Z) Coordinates of first starting point for streamline plot (only if dStreamlineSlice = 1)
inDefault.dStreamlineStartPoint2 = {}; %(X;Y;Z) Coordinates of second starting point for streamline plot (only if dStreamlineSlice = 1)
%inDefault.tStreamlineDensity = []; %see Strealines plot settings 

%% Singleplotter settings
inDefault.sSavePlot = []; % Save single plot [0,1]
inDefault.sFormatFig = {}; % ['fig','png','jpeg','bmp','pdf','meta',etc.]
inDefault.sFigRenderer = {}; % ['opengl','painters'] painters produces vectorial figures, opengl rasterised figures
inDefault.sLeftEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sBottomEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sPlotHeight = []; %in cm
inDefault.sPlotWidth = []; %in cm

%% Multiplotter settings (Only values set in the first line of the input file are used)
inDefault.mPlotAct = []; % Save all plots in one file [0,1]
inDefault.mFormatFig = {}; %['pdf','emf','png']
inDefault.mResolution = {}; %works only if Renderer is opengl (e.g. r400)
inDefault.mMainTitle = {}; %To be shown on top of the page
inDefault.mGraphsxColumn = []; %Set the figure grid in the multiplot
inDefault.mGraphsxRow = []; %Set the figure grid in the multiplot
inDefault.mLeftEdge = []; %This variables control the spacing between figures (in cm)
inDefault.mRightEdge = [];
inDefault.mTopEdge = [];
inDefault.mBottomEdge = [];
inDefault.mSpaceX = [];
inDefault.mSpaceY = [];
inDefault.mPlotHeight = []; %Page height in cm
inDefault.mPlotWidth = []; %Page width in cm
inDefault.mMainTitleFontSize = []; %Fontsize of mMainTitle
inDefault.mFontSize = []; %Fontsize of all the other text (replace fFontSize only in the multiplot)
inDefault.mInterpreterText = {}; % ['latex','none'] Applies only for the mMainTitle
inDefault.mFigRenderer = {}; % ['opengl','painters'] painters produces vectorial figures, opengl rasterised figures
inDefault.mSingleColorbar = []; % [0,1] Show only the colorbar of the first graph superimposed at the desired location (works only if colorbar range is set for the first figure, whose properties are automatically extended to all the other figures)
inDefault.mSingleColorbarOrientation = {}; %['Vertical','Horizontal']
inDefault.mSingleColorbarLocation = {}; %[leftEdge,bottomEdge,width,height] location of the centre of the colorbar (where 0 is the right paper edge, 1 the left edge) if mSingleColorbar = 1