function [errorMsg, warningMsg] = plotter2D
%plotter2D    Create 2D contour graphs, streamlines and vector plots
%   errorMsg = plotter2D  creates 2D contour graphs, streamlines and vector
%   plots, and saves them in separate files or in a single multiplot. An
%   interactive window also showup on command. 3D plots are also possible
%   showing the measuring points and 2D contour graphs in the 3D space

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 07/03/2021
% $ Version: 2.1g
%%
%close all; clc
%tic
errorMsg = [];
warningMsg = {};
%Load input variables
[in, nInputLines, errorMsg] = inputVariablesloader2D('Input\2D\Input2D.xls');
if ~isempty(errorMsg)
    return
end
%Load result files
[loc, pos, Q, Qvector2D, Qvector3D, errorMsg] = resultFileLoader2D(nInputLines,in); %loc is an array of three column matrices containing the X, Y, Z coordinates for each measuring point
%pos is an array of two column matrices containing the X, Y coordinates for each point in each graph
%Q is an array of single column vectors containing the values for each point for each contourplot
%Qvector3D is an array of three column matrices containing the values for streamlines and vector plots.
%Qvector2D is an array containing only 2D vector components and it is used in 2D vector and streamlines plotters.
if ~isempty(errorMsg)
    return
end

%% Execute actions on each result file
%Initialise variables
axisHandleList = cell(1,nInputLines);
warningMsg = cell(1,nInputLines); %Initialise warning msg array
FigsNr = max(vertcat(in.fFigureNr)); %Nr of figures (which differs from nInputLines in case figures are specified in multiplot input lines)
geometryHistory.string = '';
geometryHistory.bldg = {};
geometryHistory(2:3) = geometryHistory; %The geometry slice is computed and stored in this array. Each further geometry slice will be computed and added here only if it differs from the previous ones
PNRotMat = cell(1,nInputLines); %This is an array of structures including informations on the rotation and translation of the points and vectors. It is computed only if the forth and fifth column of a datafile are left empty (only the header must be specified)
geoCounter = 1; %Counter for different geometry slice plots
for i = 1:nInputLines
    %Set if the interactive window must show up
    if in(i).fShowFigure == 0
        set(0,'DefaultFigureVisible','off');
        f = figure(in(i).fFigureNr);
        set(f,'Visible','off') %This needs to be set to off because the figure will try to show up again if called a second time even though 'DefaultFigureVisible' is 'off'
    else
        set(0,'DefaultFigureVisible','on');
        f = figure(in(i).fFigureNr);
    end
    
    hold on
    plotOrder = arrayfun(@str2double, num2str(in(i).fPlotOrder)); %Create a vector from a multidigit number indicating the order of the plots
    if isempty(in(i).ldRefPointCoord)
        RefPointCoord = [NaN; NaN; NaN];
    else
        RefPointCoord = in(i).ldRefPointCoord;
    end
    if isempty(in(i).ldRefArrowBaseCoord) && isempty(in(i).ldRefArrowComponents)
        RefArrowBaseCoord = [NaN; NaN; NaN];
        RefArrowComponents = [NaN; NaN; NaN];
    else
        RefArrowBaseCoord = in(i).ldRefArrowBaseCoord;
        RefArrowComponents = in(i).ldRefArrowComponents;
    end
    if in(i).lLocationAct || in(i).d3DAct 
        [warningMsg{i}, errorMsg] = plotter2D3D(pos, Q, Qvector3D, PNRotMat, loc, in, i);
    else
        if isnan(min(pos{i}(:,1))) && isnan(min(pos{i}(:,2))) %Condition met if forth and fifth column in datafile are empty, which trigger the automatic search of the section plane from the measuring points location
            [pos{i}, Qvector3D{i}, Qvector2D{i},PNRotMat{i}, RefPointCoord, RefArrowBaseCoord, RefArrowComponents, warningMsg{i}] = posFinder2D(loc{i}, Qvector2D{i}, Qvector3D{i}, in(i), RefPointCoord, RefArrowBaseCoord, RefArrowComponents, i);
        end
        for j = 1:length(plotOrder)
   
            % plot contour graph
            if in(i).cContourAct && plotOrder(j) == 1
                errorMsg = contourPlotter2D(pos{i}, Q{i}, in(i), i);
            end
            % plot scatter graph
            if in(i).cScatterAct && plotOrder(j) == 2
                errorMsg = scatterPlotter2D(pos{i}, Q{i}, in(i), i);
            end
            % plot streamlines
            if in(i).tStreamlineAct && plotOrder(j) == 3
                if ~isempty(Qvector2D{i})
                    errorMsg = streamlinePlotter2D(pos{i}, Qvector2D{i}, in(i), i);
                else
                    warningMsg{i} = 'A Streamline plot was requested but no vectorial data was found';
                end
            end
            % plot vectors
            if in(i).vVectorAct && plotOrder(j) == 4
                if ~isempty(Qvector2D{i})
                    errorMsg = vectorPlotter2D(pos{i}, Qvector2D{i}, in(i), i);
                else
                    warningMsg{i} = 'A Vector plot was requested but no vectorial data was found';  
                end
            end
            % plot model geometry
            if in(i).gGeometryAct && plotOrder(j) == 5
                [errorMsg, geoHistNew] = geometryPlotter2D(in(i), i, geometryHistory, PNRotMat{i});
                if isempty(errorMsg) && ~isempty(geoHistNew.string) %The geometry slices are stored in geometryHistory, so if they are always the same they have to be computed only once.
                    geometryHistory(geoCounter).string = geoHistNew.string; %It is a string which identify uniquely the slice (it is creating combining the relevant input settings)
                    geometryHistory(geoCounter).bldg = geoHistNew.bldg;
                    geoCounter = geoCounter+1;
                end
                clear geoHistNew
            end
            if ~isempty(errorMsg)
                return
            end
        end
        
        % Plot reference point (if any)
        if ~isempty(in(i).ldRefPointCoord) && ~isempty(in(i).ldRefPointSize) && ~isempty(in(i).ldRefPointColor)
            scatter(RefPointCoord(1),RefPointCoord(2),...
                in(i).ldRefPointSize,in(i).ldRefPointColor,'p','filled','MarkerEdgeColor','k');
        end
        
        %% Plot reference vector (if any)
        if ~isempty(in(i).ldRefArrowBaseCoord) && ~isempty(in(i).ldRefArrowComponents) && ~isempty(in(i).ldRefArrowSize) && ...
                ~isempty(in(i).ldRefArrowColor)
            quiver(RefArrowBaseCoord(1),RefArrowBaseCoord(2),...
                RefArrowComponents(1),RefArrowComponents(2),...
                'MaxHeadSize',in(i).ldRefArrowSize,'LineWidth',in(i).ldRefArrowSize,'color',in(i).ldRefArrowColor);
        end
        
    end
    if ~isempty(errorMsg)
        return
    end
    hold off
    if in(i).fShowFigure == 1 || in(i).sSavePlot == 1
        % Set axis settings
        xlabel(in(i).fAxisLabelX,'interpreter',in(i).fInterpreterText);
        ylabel(in(i).fAxisLabelY,'interpreter',in(i).fInterpreterText);
        title(in(i).fTitle,'interpreter',in(i).fInterpreterText);
        % Set axis settings
        if in(i).fLogAxis(1) == 1
            set(gca,'XScale','log');
        end
        if in(i).fLogAxis(2) == 1
            set(gca,'YScale','log');
        end
        
        if ~isempty(in(i).fAxisLimX)
            if in(i).fReverseAxis(1) %in case the reverse axis option is active the axis range is changed of sign and swapped
                xlim([-in(i).fAxisLimX(2) -in(i).fAxisLimX(1)])
            else
                xlim([in(i).fAxisLimX(1) in(i).fAxisLimX(2)])
            end
        end
        if ~isempty(in(i).fAxisLimY)
            if in(i).fReverseAxis(2) %in case the reverse axis option is active the axis range is changed of sign and swapped
                ylim([-in(i).fAxisLimY(2) -in(i).fAxisLimY(1)])
            else
                ylim([in(i).fAxisLimY(1) in(i).fAxisLimY(2)])
            end
        end
        %Reverse axis
        if in(i).fReverseAxis(1) == 1 || in(i).fReverseAxis(2) == 1
            reverseAxis2D(in(i),0)
        end  
        set(gca,'XGrid',in(i).fGrid(1),'XMinorGrid',in(i).fGridMinor(1),'YGrid',in(i).fGrid(2),'YMinorGrid',in(i).fGridMinor(2),...
            'FontSize',in(i).fFontSize,'box','on');
        %Keep correct aspect ratio in graph
        if in(i).fKeepAspectRatio == 1 || in(i).lLocationAct || in(i).d3DAct
            set(gca,'DataAspectRatio',[1 1 1])
        end
        if in(i).lLocationAct || in(i).d3DAct
            set(gca,'ZGrid',in(i).fGrid(3),'ZMinorGrid',in(i).fGridMinor(3));
            
            if in(i).fLogAxis(3) == 1
                set(gca,'ZScale','log');
            end
            
            zlabel(in(i).fAxisLabelZloc,'interpreter',in(i).fInterpreterText)
            
            if ~isempty(in(i).fAxisLimZloc)
                zlim([in(i).fAxisLimZloc(1) in(i).fAxisLimZloc(2)])
            end
     
        end
        if ~isempty(in(i).ldViewAngles)
            view(in(i).ldViewAngles(1),in(i).ldViewAngles(2))
        end
    end
    axisHandleList{i} = gca;
    
    % Save single figure
    if in(i).sSavePlot == 1
        singlePlotter2D(gcf,in(i),i)
    end
end
clear loc f pos Q i singlefoldername firstTimeSingleFoldername Qvector plotOrder j Xaxis Yaxis geoCounter geometryHistory RefPointCoord RefArrowBaseCoord RefArrowComponents

%% Save MultiPlot
if in(1).mPlotAct == 1
    errorMsg = multiPlotter2D(in,FigsNr,axisHandleList);
end

warningMsg = warningMsg(~cellfun('isempty',warningMsg)); %Remove empty cells in array

%toc