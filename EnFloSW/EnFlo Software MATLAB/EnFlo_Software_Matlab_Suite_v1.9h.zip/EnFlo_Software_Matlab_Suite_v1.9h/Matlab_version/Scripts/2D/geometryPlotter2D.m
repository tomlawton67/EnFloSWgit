function [errorMsg, geoHistNew] = geometryPlotter2D(in,nInputLine, geoHistOld, PNRotMat)
%geometryPlotter2D    Produce a 2D geometry by making a slice of a 3D stl
%                     at the indicated plane
%   [errorMsg, geoHistNew] = geometryPlotter2D(in,nInputLine, geoHistOld)  
%    outputs a 2D geometry by making a slice of a 3D stl at the indicated plane. 
%    "geoHist" is a structure containing the histody of the previous cut
%    and it is constantly checked and updated if new geometries are found.

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 22/05/2019
% $ Version: 1.6

%%
errorMsg = [];
geoHistNew = [];
%geoHistNew.string is a string which includes as text all the input
%variables which may affect the generation of the slice of geometry. This
%is used as label for the geometry slice and stored with the slice itselt.
%So if the same geometry slice is used another time in the same run, the
%same cut will not be produced again but the one already available will be
%used, instead (to save time)
if isempty(in.gGeometryPlanarPoints) && ~isempty(PNRotMat)
    geoHistNew.string = [in.gldGeometryFilename,num2str(PNRotMat.Normal2),num2str(PNRotMat.Point2),num2str(in.fFlipNormal'),num2str(in.gldGeometryTranslations'),...
        num2str(in.gldGeometryRotations'),num2str(in.fAxisLimX'),num2str(in.fAxisLimY'),num2str(in.fAxisLimZloc'),num2str(in.gGeometryOversizeMargin)];
elseif ~isempty(in.gGeometryPlanarPoints) 
    geoHistNew.string = [in.gldGeometryFilename, num2str(in.gGeometryPlanarPoints(1,:)),...
        num2str(in.gGeometryPlanarPoints(2,:)),num2str(in.gGeometryPlanarPoints(3,:)),num2str(in.fFlipNormal'),...
        num2str(in.gldGeometryTranslations'),num2str(in.gldGeometryRotations'),num2str(in.fAxisLimX'),num2str(in.fAxisLimY'),num2str(in.fAxisLimZloc'),num2str(in.gGeometryOversizeMargin)];
else
    errorMsg = ['For input file row ',num2str(nInputLine),' no in.gGeometryPlanarPoints was given, at the same time the forth and fifth column of the datafile were not empty, hence no planes can be identified'];
    return
end

newGeom = 1; %This variable indicates if the geometry slice is new or is already in memory
if ~strcmp(geoHistOld(1).string,'')
    for i1 = 1:length(geoHistOld)
        if strcmpi(geoHistNew.string,geoHistOld(i1).string)
            newGeom = 0;
            break
        end
    end
end

if newGeom == 1
    %% Load geometry from stl file
    triangles = readBinarySTL2D(in.gldGeometryFilename);
    
    %% Apply translation and rotation (if any) to align the stl geometry reference system to the one given for the plots
    triangles(:,1:3) = triangles(:,1:3) + in.gldGeometryTranslations';
    triangles(:,4:6) = triangles(:,4:6) + in.gldGeometryTranslations';
    triangles(:,7:9) = triangles(:,7:9) + in.gldGeometryTranslations';
    
    if in.gldGeometryRotations(3) ~= 0
        triangles = rotateSTL(triangles,'z',in.gldGeometryRotations(3));
    end
    if in.gldGeometryRotations(2) ~= 0
        triangles = rotateSTL(triangles,'y',in.gldGeometryRotations(2));
    end
    if in.gldGeometryRotations(1) ~= 0
        triangles = rotateSTL(triangles,'x',in.gldGeometryRotations(1));
    end
    
    %% Compute and apply rotations, compute translation (if any)
    if ~isempty(in.gGeometryPlanarPoints)
        % Geometry plane 1 Normal N1 = [0 0 1], Point A1 = [0 0 0]
        % Plotting plane 2 Normal N2, Point A2
        tf = collinear2D(in.gGeometryPlanarPoints, 1e-14); %Check if given points are collinear
        if tf == 1
            errorMsg = ['The three points given in in.gGeometryPlanarPoints for input line nr. ', num2str(nInputLine),' are collinear. Change one of them and try again.'];
            return
        end
        
        A2 = in.gGeometryPlanarPoints(1,:);
        B2 = in.gGeometryPlanarPoints(2,:);
        C2 = in.gGeometryPlanarPoints(3,:);
        
        AB = A2-B2; %Vector laying on plane 2
        BC = C2-B2; %Vector laying on plane 2
        N2 = cross(AB,BC)/norm(cross(AB,BC)); %normal to plotting plane
        if in.fFlipNormal(1) == 1
            N2 = -N2;
        end
        
        if in.fFlipNormal(2) == 1
            RefNormal = [0 0 -1];
        else
            RefNormal = [0 0 1];
        end
        [P, N, check] = planeIntersect2D(RefNormal, [0 0 0], N2, A2); %N is the interpect axis between plane 1 and 2, P is a point laying on axis N
        N = N/norm(N); %Intersection axis between plane 1 and 2 normalised
        %Plane 1 equation a1*x+b1*y+c1*z+d1=0
        a1=0; b1=0; c1=1;%d1=0;
        %Plane 2 equation a2*x+b2*y+c2*z+d2=0
        a2 = N2(1); b2 = N2(2); c2 = N2(3);
        
        %Angle between plane 1 and 2: alpha
        cosalpha = abs(a1*a2+b1*b2+c1*c2)/(sqrt(a1^2+b1^2+c1^2)*sqrt(a2^2+b2^2+c2^2));
        c = cosalpha;
        s = sqrt(1-c^2);
        C = 1-c;
        x = N(1); y = N(2); z = N(3);
        rmat = [x^2*C+c    x*y*C-z*s  x*z*C+y*s;... %Rotation matrix around N-axis of angle alpha
            y*x*C+z*s  y^2*C+c    y*z*C-x*s;...
            z*x*C-y*s  z*y*C+x*s  z^2*C+c];
    else
        A2 = PNRotMat.Point2;
        P =  PNRotMat.IntersectionPoint;
        N =  PNRotMat.IntersectionAxis;
        rmat = PNRotMat.rmat;    
        check = PNRotMat.check;
    end
    
    switch check
        case 0 %Plane 1 and Plane 2 are parallel
            slice_height = A2(3); %Since plane 1 has always equation z = 1, any point parallel to this one will have a distance equal to the z-coordinate of each own point
        case 1 %Plane 1 and Plane 2 coincide
            slice_height = 0;
        case 2 %Plane 1 and Plane 2 intersect in vector N
            %Translate geometry to P
             triangles(:,1:3) = triangles(:,1:3) - P;
             triangles(:,4:6) = triangles(:,4:6) - P;
             triangles(:,7:9) = triangles(:,7:9) - P;
            
            trianglesnew = triangles;
            for i = 1:size(triangles,1) %Apply the rotation matrix to the geometry
                trianglesnew(i,1) = rmat(1,1)*triangles(i,1) + rmat(1,2)*triangles(i,2) + rmat(1,3)*triangles(i,3);
                trianglesnew(i,2) = rmat(2,1)*triangles(i,1) + rmat(2,2)*triangles(i,2) + rmat(2,3)*triangles(i,3);
                trianglesnew(i,3) = rmat(3,1)*triangles(i,1) + rmat(3,2)*triangles(i,2) + rmat(3,3)*triangles(i,3);
                
                trianglesnew(i,4) = rmat(1,1)*triangles(i,4) + rmat(1,2)*triangles(i,5) + rmat(1,3)*triangles(i,6);
                trianglesnew(i,5) = rmat(2,1)*triangles(i,4) + rmat(2,2)*triangles(i,5) + rmat(2,3)*triangles(i,6);
                trianglesnew(i,6) = rmat(3,1)*triangles(i,4) + rmat(3,2)*triangles(i,5) + rmat(3,3)*triangles(i,6);
                
                trianglesnew(i,7) = rmat(1,1)*triangles(i,7) + rmat(1,2)*triangles(i,8) + rmat(1,3)*triangles(i,9);
                trianglesnew(i,8) = rmat(2,1)*triangles(i,7) + rmat(2,2)*triangles(i,8) + rmat(2,3)*triangles(i,9);
                trianglesnew(i,9) = rmat(3,1)*triangles(i,7) + rmat(3,2)*triangles(i,8) + rmat(3,3)*triangles(i,9);
            end
            triangles = trianglesnew;
            clear trianglesnew
            
            angleXY = atand(N(2)/N(1));
            triangles = rotateSTL(triangles,'z',angleXY);           
            slice_height = 0;
    end
    
    
    %% Filter STL components outside the desired range (if a point of the geometric triangles is outside the range, delete the row)
    Threshold = in.gGeometryOversizeMargin; %This parameter defines the margin outside the selected range which will be still considered in the slicing.
    if ~isempty(in.fAxisLimX)
        RangeX(1) = in.fAxisLimX(1) - (in.fAxisLimX(2)-in.fAxisLimX(1))*Threshold;
        RangeX(2) = in.fAxisLimX(2) + (in.fAxisLimX(2)-in.fAxisLimX(1))*Threshold;
    else
        RangeX(1) = -inf;
        RangeX(2) = inf;
    end
    if ~isempty(in.fAxisLimY)
        RangeY(1) = in.fAxisLimY(1) - (in.fAxisLimY(2)-in.fAxisLimY(1))*Threshold;
        RangeY(2) = in.fAxisLimY(2) + (in.fAxisLimY(2)-in.fAxisLimY(1))*Threshold;
    else
        RangeY(1) = -inf;
        RangeY(2) = inf;
    end
    if ~isempty(in.fAxisLimZloc)
        RangeZ(1) = in.fAxisLimZloc(1) - (in.fAxisLimZloc(2)-in.fAxisLimZloc(1))*Threshold;
        RangeZ(2) = in.fAxisLimZloc(2) + (in.fAxisLimZloc(2)-in.fAxisLimZloc(1))*Threshold;
    else
        RangeZ(1) = -inf;
        RangeZ(2) = inf;
    end
    
    if ~isempty(in.fAxisLimX) || ~isempty(in.fAxisLimY) || ~isempty(in.fAxisLimZloc)
        if (triangles(1,1) > RangeX(2) || triangles(1,1) < RangeX(1)) || (triangles(1,2) > RangeY(2) || triangles(1,2) < RangeY(1)) || ...
                (triangles(1,3) > RangeZ(2) || triangles(1,3) < RangeZ(1)) || ...
                (triangles(1,4) > RangeX(2) || triangles(1,4) < RangeX(1)) || (triangles(1,5) > RangeY(2) || triangles(1,5) < RangeY(1)) || ...
                (triangles(1,6) > RangeZ(2) || triangles(1,6) < RangeZ(1)) || ...
                (triangles(1,7) > RangeX(2) || triangles(1,7) < RangeX(1)) || (triangles(1,8) > RangeY(2) || triangles(1,8) < RangeY(1)) || ...
                (triangles(1,9) > RangeZ(2) || triangles(1,9) < RangeZ(1))
            triangles = [0 0 0 0 0 0 0 0 0 0 0 10; triangles(2:end,:)];
        end
        
        for i = 2:size(triangles,1)-1
            if (triangles(i,1) > RangeX(2) || triangles(i,1) < RangeX(1)) || (triangles(i,2) > RangeY(2) || triangles(i,2) < RangeY(1)) || ...
                    (triangles(i,3) > RangeZ(2) || triangles(i,3) < RangeZ(1)) || ...
                    (triangles(i,4) > RangeX(2) || triangles(i,4) < RangeX(1)) || (triangles(i,5) > RangeY(2) || triangles(i,5) < RangeY(1)) || ...
                    (triangles(i,6) > RangeZ(2) || triangles(i,6) < RangeZ(1)) || ...
                    (triangles(i,7) > RangeX(2) || triangles(i,7) < RangeX(1)) || (triangles(i,8) > RangeY(2) || triangles(i,8) < RangeY(1)) || ...
                    (triangles(i,9) > RangeZ(2) || triangles(i,9) < RangeZ(1))
                triangles = [triangles(1:i-1,:); 0 0 0 0 0 0 0 0 0 0 0 10; triangles(i+1:end,:)];
            end
        end
        
        if (triangles(end,1) > RangeX(2) || triangles(end,1) < RangeX(1)) || (triangles(end,2) > RangeY(2) || triangles(end,2) < RangeY(1)) || ...
                (triangles(end,3) > RangeZ(2) || triangles(end,3) < RangeZ(1)) || ...
                (triangles(end,4) > RangeX(2) || triangles(end,4) < RangeX(1)) || (triangles(end,5) > RangeY(2) || triangles(end,5) < RangeY(1)) || ...
                (triangles(end,6) > RangeZ(2) || triangles(end,6) < RangeZ(1)) || ...
                (triangles(end,7) > RangeX(2) || triangles(end,7) < RangeX(1)) || (triangles(end,8) > RangeY(2) || triangles(end,8) < RangeY(1)) || ...
                (triangles(end,9) > RangeZ(2) || triangles(end,9) < RangeZ(1))
            triangles = [triangles(1:end-1,:); 0 0 0 0 0 0 0 0 0 0 0 10];
        end
        triangles = triangles(triangles(:,12)~=10,:); %Delete the rows marked with a 10 on the 12th column
    end
    
    %% Produce the slice
    [bldg, errorMsg] = sliceSTL2D(triangles, slice_height,nInputLine);
    if ~isempty(errorMsg)
        return
    end
    if isempty(bldg) %If no buildings are found it could be because the plane selected is exactly tangent to the geometry. In this case it tries again adding or substracting 0.0001 to the plane z coordinate
        [bldg, errorMsg]  = sliceSTL2D(triangles, slice_height-0.0001);
        if ~isempty(errorMsg)
            return
        end
        if isempty(bldg)
            [bldg, errorMsg]  = sliceSTL2D(triangles, slice_height+0.0001);
            if ~isempty(errorMsg)
                return
            end
        end
    end
    
    geoHistNew.bldg = bldg;
else
    bldg = geoHistOld(i1).bldg;
    geoHistNew.string = [];
end

%% Plot geometry
if ~isempty(bldg)
    for i = 1:length(bldg)
        patchHandle = patch(bldg{i}(:,1),bldg{i}(:,2),'w','FaceColor',in.gldFaceColor,'EdgeColor',in.gldEdgeColor,'edgealpha',in.gldEdgeTransparency);
        if in.gldFaceTransparency < 1
            alpha(patchHandle,in.gldFaceTransparency);
        end
    end
end
