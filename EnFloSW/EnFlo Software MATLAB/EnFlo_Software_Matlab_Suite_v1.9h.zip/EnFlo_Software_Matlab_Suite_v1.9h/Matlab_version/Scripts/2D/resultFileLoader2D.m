function [loc, pos, Q, Qvector2D, Qvector3D, errorMsg] = resultFileLoader2D(nResults,in)
%resultFileLoader2D    load the input file variables    
%   [loc, pos, Q, Qvector2D, Qvector3D, errorMsg] = resultFileLoader2D(nResults,in)  Load 
%   the result files (one for each graph) and produce three array. "loc" is
%   an array with three column matrices with X,Y,Z measuring point locations,
%   "pos" is an array of two column matrices containing the X, Y coordinates 
%   for each point in each graph."Q" is an array of single column vectors 
%   containing the values for each point for each contourplot. "Qvector" 
%   is an array of three column matrices containing the values for streamlines 
%   and vector plots (along x, y and z axes). If only two componentes of
%   the vector are available, the third not sampled should be taken as 0.
%   If fVectorComponentNr == 2, Qvector2D is used. It is an array containing only 
%   2D vector components and it is used in 2D vector and streamlines plotters. It 
%   will not be rotated and will be considered as the values the user wants to show
%   in the final graph (hence they are assumed already rotated.)

% $ Author: Davide Marucci
% $ Creation Date: 08/04/2019
% $ Last Update Date: 03/05/2020
% $ Version: 2.1

%%
errorMsg = [];
ResultData = cell(1,nResults);
loc = cell(1,nResults);
pos = cell(1,nResults);
Q = cell(1,nResults);
Qvector3D = cell(1,nResults);
Qvector2D = cell(1,nResults);
for i = 1:nResults
    if isfile(['Input\2D\Data\Data',num2str(i),'.xls'])
        ResultData{i} = tsvread(['Input\2D\Data\Data',num2str(i),'.xls']); %Import data from Result files with tsvread
        loc{i}(:,[1 2 3]) = ResultData{i}(5:end,[1 2 3]); %X, Y, Z measuring point coordinates
        pos{i}(:,[1 2]) = ResultData{i}(5:end,[4 5]); %X, Y figure axis coordinates
        if in(i).fVectorComponentNr == 0
            Q{i}(:,1) = ResultData{i}(5:end,6); %Scalar quantity
            Qvector2D{i} = [];
            Qvector3D{i} = [];
        elseif in(i).fVectorComponentNr == 2
            Q{i}(:,1) = ResultData{i}(5:end,6); %Scalar quantity
            Qvector2D{i}(:,[1 2]) = ResultData{i}(5:end,[7 8]); %Vectorial quantities (for streamlines and arrow plots)
            Qvector3D{i} = [];
        elseif in(i).fVectorComponentNr == 3
            Q{i}(:,1) = ResultData{i}(5:end,6);
            Qvector2D{i}(:,[1 2]) = ResultData{i}(5:end,[7 8]);
            Qvector3D{i}(:,[1 2 3]) = ResultData{i}(5:end,[7 8 9]);
        else
            errorMsg = ['fVectorComponentNr not specified in row ', num2str(i)];
        end
    else
        loc{i} = []; pos{i} = []; Q{i} = []; Qvector2D{i} = []; Qvector3D{i} = [];
    end
end