function singlePlotter2D(fig, in, nInputLine)
%singlePlotter2D    Save a single figure in a file    
%   singlePlotter2D(fig, in, nInputLine)  saves a figure "fig" opened 
%   in Matlab environment in the desired format. "in" is an structure 
%   with plotting options for the figure, "nInputLine" is the number of the
%   input line used to build the filename.

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 15/05/2019
% $ Version: 1.6
%%
fig.PaperUnits = 'centimeters';
fig.PaperPosition = [in.sLeftEdge in.sBottomEdge in.sPlotWidth in.sPlotHeight];
fig.Renderer = in.sFigRenderer;
set(groot,'defaultFigurePaperPositionMode','manual')
saveas(fig, ['Output\2D\SingleImage',num2str(nInputLine)], in.sFormatFig);