function nrPointsInRange = pointsInRangeCounter2D(X, Y, xlim, ylim)
%nrPointsInRange  Find the nr of points (X,Y) which lies inside the
%                 specified range (xlim,lim)
%   nrPointsInRange = pointsInRangeCounter2D(X, Y, xlim, ylim)

% $ Author: Davide Marucci
% $ Creation Date: 06/05/2021
% $ Last Update Date: 07/03/2021
% $ Version: 2.1g

counter = 0;
for i = 1:length(X)
    if X(i)>=xlim(1) && X(i)<=xlim(2) && Y(i)>=ylim(1) && Y(i)<=ylim(2)
        counter = counter + 1;
    end
end
       
nrPointsInRange = counter;