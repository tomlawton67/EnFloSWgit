function errorMsg = scatterPlotter2D(pos, Q, in, nInputLine)
%scatterPlotter2D    Produce a 2D scatter graph  
%   errorMsg = scatterPlotter2D(pos, Q, in, nInputLine)  outputs a 2D scatter graph 
%   in which "pos" are the locations (X,Y) of the points (the order does not 
%   matter) and "Q" is the value in each point. "in" is a structure containg 
%   the options of the graph.

% $ Author: Davide Marucci
% $ Creation Date: 09/04/2019
% $ Last Update Date: 31/05/2019
% $ Version: 1.8
%%
errorMsg = [];
if isempty(Q)
    errorMsg = ['No data have been found for the scatter plot of input line nr. ', num2str(nInputLine)];
    return
end


Contour_extremes = in.cdColorbarRange;

if in.cdColorbarLogarithmic == 1 %Modify data for logarithmic colorbar plot
    if min(min(Q)) < 0
        errorMsg = ['When using a logarithmic scale for the colormap no negative values are allowed. Check input line nr. ',...
            num2str(nInputLine)];
        return
    end
    Q = log10(Q);
    if ~isempty(Contour_extremes)
        Contour_extremes = log10(Contour_extremes);
    end
end

if isempty(Contour_extremes)
    Contour_levels = linspace(min(min(Q)),max(max(Q)),in.cLevNr);
elseif ~isempty(Contour_extremes) && in.cIncludeMin == 0
    Contour_levels = linspace(Contour_extremes(1),Contour_extremes(2),in.cLevNr);
elseif ~isempty(Contour_extremes) && in.cIncludeMin == 1
    Contour_levels = [min(min(Q)) linspace(Contour_extremes(1),Contour_extremes(2),in.cLevNr-1)];
end

s = scatter(pos(:,1), pos(:,2), in.cScatterPointSize, Q,'filled'); %produce scatter plot
colormap(in.cdColormap);
s.MarkerEdgeColor = 'k';

cbar = colorbar;
ylabel(cbar,in.cdColorbarLabel,'interpreter',in.fInterpreterText);

% Define colorbar in case of logarithmic option and no range specified
if isempty(in.cdColorbarRange) && in.cdColorbarLogarithmic==1
    labelPos = linspace(min(Q),max(Q),5);
    labelValue = 10.^labelPos; % Tick mark positions
    caxis([labelPos(1) labelPos(end)])
    set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
    
% Define colorbar in case of logarithmic option and range specified
elseif ~isempty(in.cdColorbarRange)
    if in.cdColorbarLogarithmic==1
        labelPos = log10(in.cdColorbarRange(1)):log10(in.cdColorbarRange(2));
        labelValue = 10.^labelPos; % Tick mark positions
        caxis([labelPos(1) labelPos(end)])
        set(cbar,'Ytick',labelPos,'YTicklabel',labelValue);
    else
            
% Define colorbar in case of no logarithmic option and range specified
        caxis([in.cdColorbarRange(1) in.cdColorbarRange(2)])
    end
end