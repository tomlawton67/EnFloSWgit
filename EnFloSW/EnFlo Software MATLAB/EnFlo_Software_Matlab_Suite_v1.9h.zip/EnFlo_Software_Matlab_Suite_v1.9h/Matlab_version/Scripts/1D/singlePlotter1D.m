function singlePlotter1D(fig, in, figNum)
%singlePlotter1D    Save a single figure in a file    
%   singlePlotter1D(fig, in, figNum)  saves a figure "fig" opened 
%   in Matlab environment in the desired format. "in" is an structure 
%   with plotting options for the figure, "figNum" is the number of the
%   figure used to build the filename.

% $ Author: Davide Marucci
% $ Creation Date: 02/04/2019
% $ Last Update Date: 07/05/2019
% $ Version: 1.5
%%
fig.PaperUnits = 'centimeters';
fig.PaperPosition = [in.sLeftEdge in.sBottomEdge in.sPlotWidth in.sPlotHeight];
fig.Renderer = in.fFigRenderer;
set(groot,'defaultFigurePaperPositionMode','manual')
saveas(fig, ['Output\1D\SingleImage',num2str(figNum)], in.sFormatFig);