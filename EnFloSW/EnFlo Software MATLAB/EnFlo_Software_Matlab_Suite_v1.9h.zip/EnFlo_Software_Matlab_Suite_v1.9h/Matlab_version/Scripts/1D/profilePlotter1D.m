function [axisHandle, fitting, errorMsg] = profilePlotter1D(data, in, figNr, nProfs)
%profilePlotter1D    Produce a profile graph
%   [axisHandle, errorMsg] = profilePlotter1D(data, in, figNr, nProfs)  outputs a profile 
%   graph in which "data" is an array containinig a sub-array for each profile 
%   in the figure. Each sub-array contains a minimum of five-column matrix. 
%   In the matrix the first three columns are X, Y and Z coordinates
%   the measuring points. The fourth column is the x-axis data, the 
%   fifth is the y-axis data. In case also the standard error is present it 
%   will be in the sixth column and following columns. "in" is a structure 
%   containg the options of the graph, figNr is the number of the figure.

% $ Author: Davide Marucci
% $ Creation Date: 11/04/2019
% $ Last Update Date: 03/06/2019
% $ Version: 1.7
%%
axisHandle = [];
errorMsg = [];
fittedProf = find(in.pFitOn==1); 
nFit = length(fittedProf); %Number of profile fitting requested
fitting.coeffFit = {};
fitting.errorFit = [];
fitting.fittedProf = [];
plotHandle = cell(1,(nProfs+nFit));
legendStrings = cell(1,(nProfs+nFit));
doubleYaxis = 0; %It will be changed to 1 if at least one profile will refer to the right Y axis
ProfRight = find(in.pAxisYright==1); %Indeces of the profiles which refer to the right Y axis
FitRightNr = length(ismember(ProfRight,fittedProf)); %Nr of fitted profiles which refers to profiles referring to the right Y axis
legendIdx = 1; %Index which define the location of the i-legend element inside legendStrings
legendIdxRight = (nProfs+nFit) - (length(ProfRight)+FitRightNr) + 1; %Index which define the location of 
%    the i-legend element inside legendStrings (when the profile refers to the right Y axis). A separated index counter is necessary since all
%    the profiles refering to the right Y axis will be listed at the end

%% Plot profiles
for i = 1:nProfs
    if in.pAxisYright(i) == 1 %Set y axis right
        yyaxis right; doubleYaxis = 1;
    end
    if strcmpi(in.fErrorbarOrientation,'none')
        plotHandle{i} = plot(data{i}(:,4),data{i}(:,5));   
    elseif (strcmpi(in.fErrorbarOrientation,'vertical') || strcmpi(in.fErrorbarOrientation,'horizontal')) && in.fErrorbarColumn==1
        plotHandle{i} = errorbar(data{i}(:,4),data{i}(:,5),data{i}(:,6),in.fErrorbarOrientation);
    elseif (strcmpi(in.fErrorbarOrientation,'vertical') || strcmpi(in.fErrorbarOrientation,'horizontal')) && in.fErrorbarColumn==2
        plotHandle{i} = errorbar(data{i}(:,4),data{i}(:,5),data{i}(:,6),data{i}(:,7),in.fErrorbarOrientation);      
    elseif strcmpi(in.fErrorbarOrientation,'both') && in.fErrorbarColumn==1
        plotHandle{i} = errorbar(data{i}(:,4),data{i}(:,5),data{i}(:,7),data{i}(:,7),data{i}(:,6),data{i}(:,6));
    elseif strcmpi(in.fErrorbarOrientation,'both') && in.fErrorbarColumn==2
        plotHandle{i} = errorbar(data{i}(:,4),data{i}(:,5),data{i}(:,8),data{i}(:,9),data{i}(:,6),data{i}(:,7));
    end
    set(plotHandle{i},'linewidth',in.pLineWidth(i),'linestyle',in.pLineStyle{i},'Marker',in.pLineMarker{i},...
        'MarkerSize',in.pMarkerSize(i),'color',in.pLineColor{i})  
    
    if in.pAxisYright(i) == 1    
        yyaxis left  %Reset axis to default left       
        legendStrings{legendIdxRight} = in.pLegendLabel{i};
        legendIdxRight = legendIdxRight + 1;
    else     
        legendStrings{legendIdx} = in.pLegendLabel{i};
        legendIdx = legendIdx + 1;
    end
end

%% Compute and plot fitting profiles (if any)
if nFit ~= 0 
    fitting.coeffFit = cell(nFit,1); fitting.errorFit = zeros(nFit,1);
    for i = 1:nFit %Profile fitting
        fitting.fittedProf(i) = fittedProf(i);
        [Xfit, Yfit, fitting.coeffFit{i}, fitting.errorFit(i)] = profileFitter1D(data{fittedProf(i)}, in, fittedProf(i));        
        if in.pAxisYright(i) == 1
            yyaxis right
        end
        plotHandle{nProfs+i} = plot(Xfit, Yfit);
        set(plotHandle{nProfs+i},'linewidth',in.pLineWidth(fittedProf(i)),'linestyle',in.pLineStyle{fittedProf(i)},'color',in.pLineColor{fittedProf(i)},'Marker','none')
        set(plotHandle{fittedProf(i)},'linestyle','none')
        
        if in.pAxisYright(i) == 1
            yyaxis left  %Reset axis to default left
            legendStrings{legendIdxRight} = ['Fitting prof. ',num2str(fittedProf(i))];
            legendIdxRight = legendIdxRight + 1;
        else
            legendStrings{legendIdx} = ['Fitting prof. ',num2str(fittedProf(i))];
            legendIdx = legendIdx + 1;
        end
    end
end

%% Set axis properties and figure labels (if needed)
if in.fShowFigure == 1 || in.sSavePlot == 1
    
    % Set axis settings
    if in.fLogAxis(1) == 1
        set(gca,'XScale','log');
    end
    if in.fLogAxis(2) == 1
        set(gca,'YScale','log');
    end
    
    xlabel(in.fAxisLabelX,'interpreter',in.fInterpreterText);
    ylabel(in.fAxisLabelY,'interpreter',in.fInterpreterText);
    title(in.fTitle,'interpreter',in.fInterpreterText);
    if ~isempty(in.fAxisLimX)
        xlim([in.fAxisLimX(1) in.fAxisLimX(2)])
    end
    if ~isempty(in.fAxisLimY)
        ylim([in.fAxisLimY(1) in.fAxisLimY(2)])
    end
    
    if doubleYaxis == 1
        ax = gca;
        ax.YColor = 'k'; %Restore left Y axis color to black 
        yyaxis right;
        ax.YColor = in.fYrightAxisColor; %Set right Y axis color
        if ~isempty(in.fAxisLimYrightZloc)
            xlim([in.fAxisLimYrightZloc(1) in.fAxisLimYrightZloc(2)])
        end
        ylabel(in.fAxisLabelYrightZloc,'interpreter',in.fInterpreterText);
        if in.fLogAxis(3) == 1
            set(gca,'YScale','log');
        end
        yyaxis left;
    end
    
    set(gca,'XGrid',in.fGrid(1),'XMinorGrid',in.fGridMinor(1),'YGrid',in.fGrid(2),'YMinorGrid',in.fGridMinor(2),...
        'FontSize',in.fFontSize,'box','on');
    
    if in.fShowLegend == 1
        legendHandle = legend(legendStrings,'interpreter',in.fInterpreterText,'location',in.fLegendLocation);
    end
    
    if ~isempty(in.fLegendTitle)
        title(legendHandle,in.fLegendTitle,'interpreter',in.fInterpreterText);
    end
    
    if in.fShowLegendBox == 0
        legend boxoff
    end
end

axisHandle = cell(2,1);
axisHandle{1} = gca; %Export axis properties
axisHandle{2} = doubleYaxis;