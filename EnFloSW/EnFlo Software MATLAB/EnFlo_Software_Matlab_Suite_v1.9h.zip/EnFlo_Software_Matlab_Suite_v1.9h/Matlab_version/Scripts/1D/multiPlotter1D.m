function multiPlotter1D(in, figsNr, axisHandleList, ProfNrxFig)
%multiPlotter1D    Produce and save multiplot files    
%   multiPlotter1D(in, figsNr, axisHandleList, ProfNrxFig)  collects all the 
%   opened figures in Matlab environment and produces a subplot image with all of them. 
%   The image is then saved in the desired format. "in" is an array containg 
%   one structure with plotting options for each figure, "figsNr" is the number 
%   of figures. "ProfNrxFig" is the number of profiles for each figure.

% $ Author: Davide Marucci
% $ Creation Date: 12/04/2019
% $ Last Update Date: 14/05/2019
% $ Version: 1.7
%%
sub_pos = subplotPos(in(1).mPlotWidth,in(1).mPlotHeight,in(1).mLeftEdge,in(1).mRightEdge,in(1).mBottomEdge,...
    in(1).mTopEdge,in(1).mGraphsxColumn,in(1).mGraphsxRow,in(1).mSpaceX,in(1).mSpaceY);

%setting the Matlab figure
f2 = figure('visible','off');
clf(f2);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [in(1).mPlotWidth in(1).mPlotHeight]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 in(1).mPlotWidth in(1).mPlotHeight]);

j = 1; %loop counter
for i = in(1).mGraphsxRow:-1:1 %iteration on the columns
    for ii = 1:in(1).mGraphsxColumn %iteration on the rows
        if j <= figsNr && j <= in(1).mGraphsxColumn*in(1).mGraphsxRow
            ax = axes('position',sub_pos{ii,i},'XGrid',in(j).fGrid(1),'XMinorGrid',in(j).fGridMinor(1),...
                'YGrid',in(j).fGrid(2),'YMinorGrid',in(j).fGridMinor(2),'FontSize',in(1).mFontSize,'Box','on','Layer','top');
            
            if axisHandleList{j}{2} == 0 % only 1 Y axis present
                fig1 = get(axisHandleList{j}{1},'children'); %get handle to all the children in the figure
                copyobj(fig1,ax); %copy children to new parent axes i.e. the subplot axes
                
            elseif axisHandleList{j}{2} == 1 %Double Y axis present
                figOld = figure(j);     
                yyaxis left;
                fig1 = get(axisHandleList{j}{1},'children'); %get handle to all the children in the figure
                figNew = figure(figsNr+1);
                yyaxis left;
                copyobj(fig1,ax); %copy children to new parent axes i.e. the subplot axes
                figOld = figure(j); 
                if in(j).fShowFigure == 0
                    set(figOld,'Visible','off');
                end
                yyaxis right;
                fig2 = get(axisHandleList{j}{1},'children'); %get handle to all the children in the figure
                figNew = figure(figsNr+1); set(figNew,'Visible','off');
                yyaxis right;
                copyobj(fig2,ax); %copy children to new parent axes i.e. the subplot axes
                yyaxis left;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if in(j).fLogAxis(1) == 1
                set(gca,'XScale','log');
            end
            if in(j).fLogAxis(2) == 1
                set(gca,'YScale','log');
            end
            
            if ~isempty(in(j).fAxisLimX)
                xlim([in(j).fAxisLimX(1) in(j).fAxisLimX(2)])
            end
            if ~isempty(in(j).fAxisLimY)
                ylim([in(j).fAxisLimY(1) in(j).fAxisLimY(2)])
            end
            
            title(in(j).fTitle,'interpreter',in(j).fInterpreterText,'fontsize',in(1).mFontSize)
            xlabel(in(j).fAxisLabelX,'interpreter',in(j).fInterpreterText,'fontsize',in(1).mFontSize)            
            ylabel(in(j).fAxisLabelY,'interpreter',in(j).fInterpreterText,'fontsize',in(1).mFontSize)
            
            if in(j).fTickLabel(1) == 0
                set(gca,'XTickLabel',[])
            end
            if in(j).fTickLabel(2) == 0
                set(gca,'YTickLabel',[])
            end
            
            if axisHandleList{j}{2} == 1 %right Y axis settings (if any)
                ax = gca;
                ax.YColor = 'k'; %Restore left Y axis color to black 
                yyaxis right;
                ax.YColor = in.fYrightAxisColor; %Set right Y axis color
                if in(j).fLogAxis(3) == 1
                    set(gca,'YScale','log');
                end
                if ~isempty(in(j).fAxisLimYrightZloc)
                    ylim([in(j).fAxisLimYrightZloc(1) in(j).fAxisLimYrightZloc(2)])
                end
                ylabel(in(j).fAxisLabelYrightZloc,'interpreter',in(j).fInterpreterText,'fontsize',in(1).mFontSize)
                if in(j).fTickLabel(3) == 0
                    set(gca,'YTickLabel',[])
                end                
                yyaxis left;
            end
            
            if in(j).lLocationAct == 1 %Location plot
                if in(j).fLogAxis(3) == 1
                    set(gca,'ZScale','log');
                end
                set(gca,'ZGrid',in(j).fGrid(3),'ZMinorGrid',in(j).fGridMinor(3));
                zlabel(in(j).fAxisLabelYrightZloc,'interpreter',in(j).fInterpreterText)
                if in(j).fTickLabel(3) == 0
                    set(gca,'ZTickLabel',[],'TickLength',[0 0])
                end
                if ~isempty(in(j).fAxisLimYrightZloc)
                    zlim([in(j).fAxisLimYrightZloc(1) in(j).fAxisLimYrightZloc(2)])
                end
                view(in(j).lViewAngles(1),in(j).lViewAngles(2))
                set(gca,'DataAspectRatio',[1 1 1])
            end
            j = j + 1;
        end
    end
end

% Insert main title on top of multiplot
if ~isempty(in(1).mMainTitle)
    multiPlotMainTitle(in(1).mMainTitle, in(1).mInterpreterText, in(1).mMainTitleFontSize);
end

multiPlotLegend1D(in, ProfNrxFig) %Plot legend

%% Save image
set(gcf, 'Renderer', in(1).mFigRenderer)
switch in(1).mFormatFig
    case 'pdf'
        print(gcf, '-dpdf',['-',in(1).mResolution],'-loose','Output\1D\MultiImage.pdf');
    case 'emf'
        print(gcf, '-dmeta',['-',in(1).mResolution],'-loose','Output\1D\MultiImage.emf');
    case 'png'
        print(gcf, '-dpng',['-',in(1).mResolution],'-loose','Output\1D\MultiImage.png');
end