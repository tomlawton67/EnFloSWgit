function multiPlotLegend1D(in, ProfNrxFig)
%multiPlotLegend1D    Produce a legend for the multiplot file
%   multiPlotLegend1D(in, ProfNrxFig)  produces a legend with a line for each profile
%   with different settings shown in the multiplot. The legend is placed in
%   the lower right corner of the multiplot, if not differently specified.
%   ProfNrxFig is the number of profiles for each figure.

% $ Author: Davide Marucci
% $ Creation Date: 15/04/2019
% $ Last Update Date: 08/05/2019
% $ Version: 1.5

%% 
%Create a structure for each profile property including all the profiles plotted in all the figures
totalProfNr = sum(ProfNrxFig);
all.LegendLabel = cell(totalProfNr,1);
all.LineColor = cell(totalProfNr,1);
all.LineStyle = cell(totalProfNr,1);
all.LineWidth = zeros(totalProfNr,1);
all.LineMarker = cell(totalProfNr,1);
all.MarkerSize = zeros(totalProfNr,1);
allString = cell(totalProfNr,1); %It is an array containing all the profile properties connected as a string
counter = 1;
for i = 1:length(in)
    if ~in(i).lLocationAct
        for j = 1:length(in(i).pLegendLabel)
            all.LegendLabel{counter,1} = in(i).pLegendLabel{j};
            all.LineColor{counter,1} = in(i).pLineColor{j};
            all.LineStyle{counter,1} = in(i).pLineStyle{j};
            all.LineWidth(counter,1) = in(i).pLineWidth(j);
            all.LineMarker{counter,1} = in(i).pLineMarker{j};
            all.MarkerSize(counter,1) = in(i).pMarkerSize(j);
            allString{counter,1} = [in(i).pLegendLabel{j} in(i).pLineColor{j} in(i).pLineStyle{j} num2str(in(i).pLineWidth(j)) in(i).pLineMarker{j} num2str(in(i).pMarkerSize(j))];
            counter = counter + 1;
        end
    end
end

[ProfList,ProfStartRow] = unique(allString); %Take one profile as representative of all the other with similar properties 
[ProfStartRow,order] = sort(ProfStartRow,'ascend'); %Arrange the order of the profiles in an ascend way

ax = axes('Units','Normal','Position',[0 0 1 1],'Visible','off'); %Set an invisible figure as large as the paper

% Plot one point for each unique profile
legendStrings = cell(length(ProfStartRow),1);
for i = 1:length(ProfStartRow)
    plotHandle = plot(10, 10);
    hold on
    set(plotHandle,'linewidth',all.LineWidth(ProfStartRow(i)),'linestyle',all.LineStyle{ProfStartRow(i)},'Marker',all.LineMarker{ProfStartRow(i)},...
        'MarkerSize',all.MarkerSize(ProfStartRow(i)),'color',all.LineColor{ProfStartRow(i)})
    legendStrings{i} = all.LegendLabel{ProfStartRow(i)};
end
hold off
xlim([0 1]); ylim([0 1]); %Set axis limit to be smaller than the plotted point coordinates (so the point will not be shown)

legendHandle = legend(legendStrings, 'interpreter', in(1).mInterpreterText,'Position',[in(1).mLegendLocation(1) in(1).mLegendLocation(2) 0 0]); %plot legend
set(gca,'visible','off')

legendHandle.NumColumns = in(1).mLegendColumnNr;

if in(1).mShowLegendBox == 0
    legend boxoff
end

if ~isempty(in(1).mLegendTitle)
    title(legendHandle,in(1).mLegendTitle,'interpreter',in(1).mInterpreterText);
end
