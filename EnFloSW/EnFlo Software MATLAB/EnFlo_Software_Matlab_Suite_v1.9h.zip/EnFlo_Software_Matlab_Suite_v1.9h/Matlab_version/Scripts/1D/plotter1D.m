function errorMsg = plotter1D
%plotter1D    Create 1D line graphs
%   errorMsg = plotter1D  creates 1D line graphs, and saves them in separated 
%   files or in a single multiplot. An interactive window also showup on command.

% $ Author: Davide Marucci
% $ Creation Date: 10/04/2019
% $ Last Update Date: 17/10/2020
% $ Version: 1.7b
%%
%clear all; close all; clc
%tic
errorMsg = [];
%Load input variables
[in, nFigures, ProfNrxFig, errorMsg] = inputVariablesLoader1D('Input\1D\Input1D.xls');
if ~isempty(errorMsg)
    return
end
%Load result files
[data, errorMsg] = resultFileLoader1D(in, nFigures); %data is an array containing a sub-array for each figure.
%Each sub-array contains a minimum of five-column matrix for each profile in the figure.
%In the matrix the first three columns are X, Y and Z coordinates
%the measuring points. The fourth column is the x-axis data, the 
%fifth is the y-axis data. In case also the standard error is present it 
%will be in the sixth column and following columns.
if ~isempty(errorMsg)
    return
end

for i = 1:length(ProfNrxFig)
    if ~isempty(data{i})
        if ProfNrxFig(i) ~= length(data{i})
            errorMsg = ['The number of profiles specified in result file ',num2str(i),...
                ' does not match the number of profiles declared in the Input1D.xls file'];
            return
        end
    end
end

%% Execute actions on each result file
axisHandleList = cell(1,nFigures);
fittingArray = cell(1,nFigures); %Structure with fitting coefficients (if any)
for i = 1:nFigures
    %Set if the interactive window must show up
    if in(i).fShowFigure == 0
        set(0,'DefaultFigureVisible','off');
    else
        set(0,'DefaultFigureVisible','on');
    end
    
    figure(i)
    hold on
    if in(i).lLocationAct == 0
        [axisHandleList{i}, fittingArray{i}, errorMsg] = profilePlotter1D(data{i}, in(i), i, ProfNrxFig(i)); % plot profiles
    else
        [axisHandleList{i}, fittingArray{i}, errorMsg] = locationPlotter1D(data, in, i); % plot location
    end
    hold off
    if ~isempty(errorMsg)
        return
    end
    
    % Save single figure
    if in(i).sSavePlot == 1
        singlePlotter1D(gcf,in(i),i)
    end
end
fittingCoeffFileWriter1D(fittingArray)
clear data i j data fittingArray

%% Save MultiPlot
if in(1).mPlotAct == 1
    multiPlotter1D(in, nFigures, axisHandleList, ProfNrxFig)
end
%toc