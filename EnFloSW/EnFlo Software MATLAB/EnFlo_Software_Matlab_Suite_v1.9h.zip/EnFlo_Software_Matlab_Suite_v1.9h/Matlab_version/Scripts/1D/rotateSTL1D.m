function v = rotateSTL1D(v,ax1,theta1)
%rotateSTL2D    Apply a rotation of an angle theta1 around axis ax1
%   v = rotateSTL2D(v,ax1,theta1)  outputs a rotated
%   geometry "v" with the rotation of angle theta1,

% $ Author: Davide Marucci
% $ Creation Date: 14/05/2019
% $ Last Update Date: 14/05/2019
% $ Version: 1.7

%%
if ax1 == 'x'
    rotmat = [1, 0, 0; 0, cosd(theta1),-sind(theta1); 0, sind(theta1),cosd(theta1)];
elseif ax1 == 'y'
    rotmat = [cosd(theta1), 0 , sind(theta1); 0,1,0; -sind(theta1) 0, cosd(theta1)];
elseif ax1 == 'z'
    rotmat = [cosd(theta1), -sind(theta1), 0; sind(theta1), cosd(theta1),0; 0, 0,1];
end
v(:,1:3) = v(:,1:3) * rotmat;