function [dataFinal, errorMsg] = resultFileLoader1D(in, nResults)
%resultFileLoader1D    load the result file data    
%   [dataFinal, errorMsg] = resultFileLoader1D(in, nResults)  Load the result 
%   files (one for each of the "nResults" graph) and produce an array called 
%   "dataFinal". "dataFinal" is an array containing a sub-array for each figure. 
%   Each sub-array contains a minimum of five-column matrix for each profile 
%   in the figure. In the matrix the first three columns are X, Y and Z coordinates
%   the measuring points. The fourth column is the x-axis data, the 
%   fifth is the y-axis data. In case also the standard error is present it 
%   will be in the sixth column and following columns.

% $ Author: Davide Marucci
% $ Creation Date: 10/04/2019
% $ Last Update Date: 03/09/2019
% $ Version: 1.7a

%%
errorMsg = [];
data = cell(1,nResults);
for i = 1:nResults    
    if isfile(['Input\1D\Data\Data',num2str(i),'.xls'])
        dataFile = tsvread(['Input\1D\Data\Data',num2str(i),'.xls']); %Import data from Result files with tsvread    
        data{i} = dataFile(5:end,:);%prof nr., x data, y data, error (either 0, 1, 2 or 4 columns)   
    else
        data{i} = [];
    end
end
clear dataFile

dataFinal = cell(1,nResults);
for i = 1:nResults
    if ~isempty(data{i})
        [ProfList,ProfStartRow] = unique(data{i}(1:end,1)); %Find different profiles for each graph and their starting row
        ProfStartRow(end+1) = length(data{i}(:,1))+1;
        for j = 1:length(ProfList) %Arrange the data so that each profile is inside a separated matrix inside each figure array
            dataFinal{i}{j} = data{i}(ProfStartRow(j):ProfStartRow(j+1)-1,[2:size(data{i},2)]);
        end
        % Check on correct results file column number
%         if ((strcmpi(in(i).fErrorbarOrientation,'none') && size(dataFinal{i}{1},2)~=5) || ...
%                 (((strcmpi(in(i).fErrorbarOrientation,'vertical') || strcmpi(in(i).fErrorbarOrientation,'horizontal')) && in(i).fErrorbarColumn==1) && size(dataFinal{i}{1},2)~=6) || ...
%                 (((strcmpi(in(i).fErrorbarOrientation,'vertical') || strcmpi(in(i).fErrorbarOrientation,'horizontal')) && in(i).fErrorbarColumn==2) && size(dataFinal{i}{1},2)~=7) || ...
%                 ((strcmpi(in(i).fErrorbarOrientation,'both') && in(i).fErrorbarColumn==2) && size(dataFinal{i}{1},2)~=9))
%             errorMsg = ['The number of columns in Input\1D\Data\Data', num2str(i),'.xls does not match the requested value according to the input settings for the errorbar'];
%             return
%         end
    end
end
