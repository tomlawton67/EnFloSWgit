function [in, nFigures, ProfNrxFig, errorMsg] = inputVariablesLoader1D(inputFileName)
%inputVariablesloader1D    load the input file variables    
%   [in, nFigures, ProfNrxFig, errorMsg] = inputVariablesloader1D(inputFileName)  
%   create an structure "in" containing the input variables with the desired plot 
%   settings from an input file.  "nFigures" is the number of figures and 
%   "ProfNrxFig" is the number of profiles for each figure.

% $ Author: Davide Marucci
% $ Creation Date: 10/04/2019
% $ Last Update Date: 15/05/2019
% $ Version: 1.7

%%
errorMsg = [];
[inputdata, fieldname, inputarray] = tsvread(inputFileName); %Read input file (inputdata is a matrix with only the numeric values, while text is shown as NaN
                                                           %fieldname is a string vector with the names taken from the first row of the input file)
                                                           %inputarray is an array with all the input entries considered as text

%Find figure starting rows in input file
FigNridx = find(strcmp(fieldname, 'pFigureNr')); %Column where bFigureNr is in input file
[FigList,FigStartRow] = unique(inputdata(2:end,FigNridx(1)));
FigStartRow = FigStartRow + 1; %Add 1 to consider the header row
FigStartRow(end+1) = size(inputdata,1)+1; %Add one fake figure at the end to compute number of profiles in last figure
nFigures = length(FigList);

%Find number of profiles for each figure
ProfNrxFig = FigStartRow(2:end) - FigStartRow(1:end-1);

%Find columns with profile settings (starting with "p") in input file
profSettingidx = startsWith(fieldname,'p');
profSettingCol = 1:length(fieldname);
profSettingCol = profSettingCol(profSettingidx);

%% Create variables structured as in from the file
in = cell(1,nFigures);
inDefault = inputVarDefault1D; %Load default values for input variables

%Check if all the required input variables have been created
fieldnameDefault = fieldnames(inDefault);
errorMsg = inputVariablesChecker1D(fieldname, fieldnameDefault); 
if ~isempty(errorMsg)
    return
end

for j = 1:nFigures
    for i = 1:length(fieldname)
        %Case in which the fieldname is a profile settings
        if ismember(i,profSettingCol)     
            if ~iscell(inDefault.(fieldname{i})) %assign numerical quantity
                jj = 1; %Profile x figure counter
                for ii = FigStartRow(j):(FigStartRow(j+1)-1) %Iterate for each profile in the figure                    
                    in{j}.(fieldname{i})(jj) = inputdata(ii,i);
                    jj = jj + 1;
                end
            else
                jj = 1; %Profile x figure counter
                for ii = FigStartRow(j):(FigStartRow(j+1)-1) %Iterate for each profile in the figure
                    in{j}.(fieldname{i}){jj} = inputarray{ii,i};
                    jj = jj + 1;
                end
            end           
        else
            %Case in which the fieldname is not a profile settings (do not iterate and take
            %only the value of the first profile of the figure as representative of the entire figure)
            if ~iscell(inDefault.(fieldname{i})) %assign numerical quantity
                in{j}.(fieldname{i}) = inputdata(FigStartRow(j),i);
                if strcmp(fieldname{i},'lLocationAct') && in{j}.(fieldname{i}) == 1 %Set prof nr = 0 if the line is a location plotter one
                    ProfNrxFig(j) = 0;
                end
            else %assign string quantity
                in{j}.(fieldname{i}) = inputarray{FigStartRow(j),i};               
                if strcmp(fieldname{i},'fAxisLimX') || strcmp(fieldname{i},'fAxisLimY') || strcmp(fieldname{i},'fAxisLimYrightZloc') || strcmp(fieldname{i},'fLogAxis') || ...
                        strcmp(fieldname{i},'fGrid') || strcmp(fieldname{i},'fGridMinor') || strcmp(fieldname{i},'fTickLabel') || ...
                        strcmp(fieldname{i},'mLegendLocation') || strcmp(fieldname{i},'lListFiguresShown') || strcmp(fieldname{i},'lLocationTranslations') || ...
                        strcmp(fieldname{i},'lLocationRotations') || strcmp(fieldname{i},'lViewAngles') || strcmp(fieldname{i},'lRefPointCoord') || ...
                        strcmp(fieldname{i},'lRefArrowBaseCoord') || strcmp(fieldname{i},'lRefArrowComponents')
                    in{j}.(fieldname{i}) = eval(['[',in{j}.(fieldname{i}),']']);
                end             
            end
        end
    end
end

in = cell2mat(in);