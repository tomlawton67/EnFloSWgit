function [axisHandle, fitting, errorMsg] = locationPlotter1D(data, in, figNr)
%locationPlotter1D    Produce a geometry plot from stl file and adds
%                     measuring points location
%   [axisHandle, errorMsg] = locationPlotter1D(data, in, figNr)  outputs 
%   a location graph in which "data" is an array containinig all the sub-arrays 
%   for each profile in each figure. Each sub-array contains a minimum of 
%   five-column matrix. In the matrix the first three columns are X, Y and 
%   Z coordinates the measuring points. "in" is a structure 
%   containg the options of the graph, figNr is the number of the figure.

% $ Author: Davide Marucci
% $ Creation Date: 14/05/2019
% $ Last Update Date: 17/10/2020
% $ Version: 1.7b
%%
errorMsg = [];
fitting.coeffFit = {};
fitting.errorFit = [];
fitting.fittedProf = [];

%% Geometry loading and plot
TR = stlread(['Input\1D\Geometry\',in(figNr).lLocationFilename]);
v = TR.Points;
f = TR.ConnectivityList;
v(:,[1 2 3]) = v(:,[1 2 3]) + in(figNr).lLocationTranslations';

if in(figNr).lLocationRotations(3) ~= 0
    v = rotateSTL1D(v,'z',in(figNr).lLocationRotations(3));
end
if in(figNr).lLocationRotations(2) ~= 0
    v = rotateSTL1D(v,'y',in(figNr).lLocationRotations(2));
end
if in(figNr).lLocationRotations(1) ~= 0
    v = rotateSTL1D(v,'x',in(figNr).lLocationRotations(1));
end

field = 'faces';      value = {f};
field2 = 'vertices';  value2 = {v};
buildings = struct(field,value,field2,value2); 

patch(buildings,'FaceColor', in(figNr).lFaceColor, 'EdgeColor', in(figNr).lEdgeColor,'edgealpha',in(figNr).lEdgeTransparency)
alpha(gca,in(figNr).lFaceTransparency)
clear f v n field field2 value value2 buildings

%% Plot Measuring points
FigList = in(figNr).lListFiguresShown;
for i = 1:length(in(figNr).lListFiguresShown)
    for j = 1:length(data{i})
        plotHandle = plot3(data{i}{j}(:,1),data{i}{j}(:,2),data{i}{j}(:,3));
        set(plotHandle,'linestyle','none','Marker',in(FigList(i)).pLineMarker{j},...
            'MarkerSize',in(FigList(i)).pMarkerSize(j),'color',in(FigList(i)).pLineColor{j});
    end
end

%% Plot reference point (if any)
if ~isempty(in(figNr).lRefPointCoord) && ~isempty(in(figNr).lRefPointSize) && ~isempty(in(figNr).lRefPointColor)
    scatter3(in(figNr).lRefPointCoord(1),in(figNr).lRefPointCoord(2),in(figNr).lRefPointCoord(3),...
        in(figNr).lRefPointSize,in(figNr).lRefPointColor,'p','filled','MarkerEdgeColor','k');
end

%% Plot reference velocity (if any)
if ~isempty(in(figNr).lRefArrowBaseCoord) && ~isempty(in(figNr).lRefArrowComponents) && ~isempty(in(figNr).lRefArrowSize) && ...
        ~isempty(in(figNr).lRefArrowColor)
    quiver3(in(figNr).lRefArrowBaseCoord(1),in(figNr).lRefArrowBaseCoord(2),in(figNr).lRefArrowBaseCoord(3),...
        in(figNr).lRefArrowComponents(1),in(figNr).lRefArrowComponents(2),in(figNr).lRefArrowComponents(3),...
        'MaxHeadSize',in(figNr).lRefArrowSize,'LineWidth',in(figNr).lRefArrowSize,'color',in(figNr).lRefArrowColor);
end

%% Axis settings
set(gca,'XGrid',in(figNr).fGrid(1),'XMinorGrid',in(figNr).fGridMinor(1),'YGrid',in(figNr).fGrid(2),'YMinorGrid',in(figNr).fGridMinor(2),...
    'ZGrid',in(figNr).fGrid(3),'ZMinorGrid',in(figNr).fGridMinor(3),'FontSize',in(figNr).fFontSize,'box','on');

if in(figNr).fLogAxis(1) == 1
    set(gca,'XScale','log');
end
if in(figNr).fLogAxis(2) == 1
    set(gca,'YScale','log');
end
if in(figNr).fLogAxis(3) == 1
    set(gca,'ZScale','log');
end

if ~isempty(in(figNr).fTitle)
    title(in(figNr).fTitle,'interpreter',in(figNr).fInterpreterText);
end

xlabel(in(figNr).fAxisLabelX,'interpreter',in(figNr).fInterpreterText)
ylabel(in(figNr).fAxisLabelY,'interpreter',in(figNr).fInterpreterText)
zlabel(in(figNr).fAxisLabelYrightZloc,'interpreter',in(figNr).fInterpreterText)

if in(figNr).fTickLabel(1) == 0
    set(gca,'XTickLabel',[],'TickLength',[0 0])    
end
if in(figNr).fTickLabel(2) == 0
    set(gca,'YTickLabel',[],'TickLength',[0 0])
end
if in(figNr).fTickLabel(3) == 0
    set(gca,'ZTickLabel',[],'TickLength',[0 0])
end

if ~isempty(in(figNr).fAxisLimX)
    xlim([in(figNr).fAxisLimX(1) in(figNr).fAxisLimX(2)])
end
if ~isempty(in(figNr).fAxisLimY)
    ylim([in(figNr).fAxisLimY(1) in(figNr).fAxisLimY(2)])
end
if ~isempty(in(figNr).fAxisLimYrightZloc)
    zlim([in(figNr).fAxisLimYrightZloc(1) in(figNr).fAxisLimYrightZloc(2)])
end

view(in(figNr).lViewAngles(1),in(figNr).lViewAngles(2))
set(gca,'DataAspectRatio',[1 1 1])

axisHandle = cell(2,1);
axisHandle{1} = gca;
axisHandle{2} = 0;