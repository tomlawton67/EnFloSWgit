function inDefault = inputVarDefault1D
%inputVarDefault1D    load the required variables names and format    
%   inDefault = inputVarDefault1D  This function lists all the possible input 
%   entry which must be specified in the Input1D.xls file. When needed an 
%   explanation of the variable function is added. Only the variable name 
%   after the dot (hence excluding inDefault.) has to be indicated as header 
%   of the input file columns. The parenteses after the equal indicates if
%   the variable is expected to be a number [] or a string {}.

% $ Author: Davide Marucci
% $ Creation Date: 10/04/2019
% $ Last Update Date: 15/05/2019
% $ Version: 1.7

%% Figure settings (read only in the first row of each new figure in the input.xls file)
inDefault.pFigureNr = []; %Figure nr. to be specified for each row as first column in Input1D.xls
inDefault.fAxisLabelX = {};
inDefault.fAxisLabelY = {};
inDefault.fAxisLabelYrightZloc = {}; %Label for either the Y-right axis (in figure with double Y axis) or the Z axis (in location plotter)
inDefault.fTitle = {};
inDefault.fAxisLimX = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimY = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimYrightZloc = {}; %[Min;Max] Axis limits for either the Y-right axis (in figure with double Y axis) or the Z axis (in location plotter)
inDefault.fLogAxis = {}; %[x-axis;yleft-axis;yright-axis] logarithmic axes. 0: linear, 1: log
inDefault.fInterpreterText = {}; % ['latex','none']
inDefault.fShowFigure = []; %Show figure in interactive window [0,1]
inDefault.fFigRenderer = {}; % ['opengl','painters']
inDefault.fGrid = {}; %[x-axis;y-axis;z-axis] Show axis grid in figure (0,1). N.B. z-axis setting works only in Location plotter
inDefault.fGridMinor = {}; %[x-axis;y-axis;z-axis] Show axis minor grid in figure (0,1). N.B. z-axis setting works only in Location plotter
inDefault.fTickLabel = {}; %[x-axis;yleft-axis;yright/Zloc-axis] Show axis tick labels (0,1)
inDefault.fFontSize = [];
inDefault.fShowLegend = []; %[0,1]
inDefault.fShowLegendBox = []; %[0,1]
inDefault.fLegendLocation = {}; %['best','north','south','bestoutside','northeastoutside',etc.]
inDefault.fLegendTitle = {}; %Title to add above the legend (if empty no legend title is added)
inDefault.fErrorbarOrientation = {}; %['none','horizontal','vertical','both']
inDefault.fErrorbarColumn = []; %[1, 2] 1 for same lower and upper limit in one column, 2 for lower and upper limit specified in different columns 
inDefault.fYrightAxisColor = {}; %Set color of right Y axis (if any) 

%% Profile plot settings (read in each row of the input.xls file)
inDefault.pAxisYright = []; %[0,1] True if the profile refers to a right Y axis, otherwise false 
inDefault.pLegendLabel = {};
inDefault.pLineColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (e.g. #FF0000)
inDefault.pLineStyle = {}; %['-','--',':','-.','none']
inDefault.pLineWidth = [];
inDefault.pLineMarker = {}; %['o','+','*','.','x','s','d','^','v','>','<','p','h','none']
inDefault.pMarkerSize = [];
inDefault.pFitOn = []; %[0,1] Activate fitting
inDefault.pFitIndepAxis = {}; %['X','Y']
inDefault.pFitEquation = {}; %'0.06*log((Y - C(1))/C(2))'
inDefault.pFitStart = {}; % List of starting points (write "[" and "]" at beginning and end). One or more values (separated by space) 
                          % for each fitting coefficient (separated by ;). If more than one starting point for each coeff
                          % is indicated, the fitting will be performed for each starting points set and the one producing
                          % the smallest fitting error will be selected
inDefault.pFitLowerBound = {}; % List of lower bounds for coeff research. One for each fitting coefficient (separated by ;)
inDefault.pFitUpperBound = {}; % List of upper bounds for coeff research. One for each fitting coefficient (separated by ;)
inDefault.pFitIndepAxisFitRange = {}; %Min and Max independent axis values inside which performing the fitting (separated by ;)
inDefault.pFitIndepAxisPlotRange = {}; %Min and Max independent axis values inside which plotting the fitting curve (separated by ;)

%% Singleplotter settings (read only in the first row of each new figure in the input.xls file)
inDefault.sSavePlot = []; % Save single plot [0,1]
inDefault.sFormatFig = {}; % ['fig','png','jpeg','bmp','pdf','meta',etc.]
inDefault.sLeftEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sBottomEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sPlotHeight = []; %in cm
inDefault.sPlotWidth = []; %in cm

%% Location plot settings
inDefault.lLocationAct = []; %Activate locationPlotter [0,1]
inDefault.lListFiguresShown = {}; %(FigureNr1;FigureNr2;...)List of figure nr. whose points are shown in the location plotter
inDefault.lLocationFilename = {}; %e.g. 'Geometry1.stl'. N.B. Geometry must be in STL format
inDefault.lLocationTranslations = {};% (X;Y;Z) Translation to apply to the stl geometry to align its origin with the plot data origin
inDefault.lLocationRotations = {};% (angleX;angleY;angleZ) angles (in degrees) to rotate to the stl geometry to align its axes with the plot data axes. The rotation will be done in the order around axis Z, Y and as last X
inDefault.lFaceColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lEdgeColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lFaceTransparency = []; %Face surface transparency value from 0 to 1 (where 0 is invisible and 1 solid)
inDefault.lEdgeTransparency = []; %Edge transparency value from 0 to 1 (where 0 is invisible and 1 solid)
inDefault.lViewAngles = {}; %(az;el) Set the viewing angles for the figure in degrees (azimuth and elevation angles)
inDefault.lRefPointCoord = {}; %(x;y;z) Coordinates of reference point (e.g. source location) (leave blank if not needed)
inDefault.lRefPointColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.lRefPointSize = []; % e.g. 20 (leave blank if not needed)
inDefault.lRefArrowBaseCoord = {}; %(x;y;z) Coordinates of reference arrow base point (e.g. wind direction) (leave blank if not needed)
inDefault.lRefArrowComponents = {}; %(x;y;z) Lengths of reference arrow in each direction (leave blank if not needed)
inDefault.lRefArrowColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.lRefArrowSize = []; % (e.g. 2) Specify the arrow line width and head size (they have to be the same) (leave blank if not needed)

%% Multiplotter settings (read only in the first row of the input.xls file)
inDefault.mPlotAct = []; % Save all plots in one file [0,1]
inDefault.mFormatFig = {}; %['pdf','emf','png']
inDefault.mResolution = {}; %works only if Renderer is opengl
inDefault.mMainTitle = {};
inDefault.mGraphsxColumn = [];
inDefault.mGraphsxRow = [];
inDefault.mLeftEdge = [];
inDefault.mRightEdge = [];
inDefault.mTopEdge = [];
inDefault.mBottomEdge = [];
inDefault.mSpaceX = [];
inDefault.mSpaceY = [];
inDefault.mPlotHeight = [];
inDefault.mPlotWidth = [];
inDefault.mMainTitleFontSize = [];
inDefault.mFontSize = [];
inDefault.mShowLegendBox = [];
inDefault.mLegendTitle = {};
inDefault.mInterpreterText = {};  % ['latex','none'] used only for multiplot legend and main title
inDefault.mFigRenderer = {}; % ['opengl','painters']
inDefault.mLegendLocation = {}; %[X,Y] location of the centre of the legend (where 0 is the right paper edge, 1 the left edge)
inDefault.mLegendColumnNr = []; %Number of columns in which the legend is arranged