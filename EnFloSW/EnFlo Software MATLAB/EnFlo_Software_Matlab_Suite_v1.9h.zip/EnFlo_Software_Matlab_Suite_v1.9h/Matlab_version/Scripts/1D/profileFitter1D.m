function [Xfit, Yfit, C, minError] = profileFitter1D(data, in, profNr)
%profileFitter    Produce a fitting of the profile
%   [Xfit, Yfit] = profileFitter1D(data, in, profNr, figNr)  outputs and plots 
%   a profile fitting. "data" is an array containinig a minimum of two-column 
%   matrix. In the matrix the first column is x-axis data and the second is 
%   y-axis data. In case also the standard error is present it will be in the 
%   third to sixth column (but it will be ignored here). "in" is a structure 
%   containg the options of the graph, profNr is the number of the profile 
%   in the figure.

% $ Author: Davide Marucci
% $ Creation Date: 26/04/2019
% $ Last Update Date: 13/05/2019
% $ Version: 1.7
%%
fun = eval(['@(C,',in.pFitIndepAxis{profNr},')',in.pFitEquation{profNr}]); %Fitting function
Cstart = eval(in.pFitStart{profNr}); %Starting points for the fitting
Clower = eval(['[',in.pFitLowerBound{profNr},']''']); %Lower bounds for the fitting
Cupper = eval(['[',in.pFitUpperBound{profNr},']''']); %Upper bounds for the fitting
fitRange = eval(['[',in.pFitIndepAxisFitRange{profNr},']''']); %Range of the independent axis in which performing the fit
plotRange = eval(['[',in.pFitIndepAxisPlotRange{profNr},']''']); %Range of the independent axis in which plotting the fitting profile
% Choose data according to indepedent axis indication
if strcmpi(in.pFitIndepAxis{profNr},'Y')
    indepData = data(:,5); depData = data(:,4);   
elseif strcmpi(in.pFitIndepAxis{profNr},'X')
    indepData = data(:,4); depData = data(:,5);    
end
%Filter data to be in the indicated fitting range
indepData1 = indepData(indepData<fitRange(2)); depData = depData(indepData<fitRange(2));
indepData = indepData1(indepData1<fitRange(2)); depData = depData(indepData1<fitRange(2));
clear indepData1

%Perform non linear fitting with lsqcurvefit function
options = optimoptions('lsqcurvefit','Display','off');
coeff = zeros(size(Cstart,2),size(Cstart,1));
errorFit = zeros(size(Cstart,2),1);
for i = 1:size(Cstart,2)
    [coeff(i,:), errorFit(i)] = lsqcurvefit(fun,Cstart(:,i),indepData,depData, Clower, Cupper,options);
end
[minError, locMin] = min(errorFit);
C  = real(coeff(locMin,:)); %Take only real part in case output is complex

%Prepare output vectors
if strcmpi(in.pFitIndepAxis{profNr},'Y')
    if (in.pAxisYright(profNr) == 0 && in.fLogAxis(2) == 1) || ... 
            (in.pAxisYright(profNr) == 1 && in.fLogAxis(3) == 1)
        Y = logspace(log10(plotRange(1)),log10(plotRange(2)),100);
    else
        Y = linspace(plotRange(1),plotRange(2),100);
    end
    depData = eval(in.pFitEquation{profNr});
    Yfit = Y;
    Xfit = depData;
elseif strcmpi(in.pFitIndepAxis{profNr},'X')
    if in.fLogAxis(1) == 1
        X = logspace(log10(plotRange(1)),log10(plotRange(2)),100);
    else
        X = linspace(plotRange(1),plotRange(2),100);
    end
    depData = eval(in.pFitEquation{profNr});
    Xfit = X;
    Yfit = depData;
end
