function fittingCoeffFileWriter1D(fittingArray)
%fittingCoeffFileWriter1D    write a fitting coefficient file
%   fittingCoeffFileWriter1D(fittingArray)  write a fitting coefficient file
%   in 'Output\1D\FittingCoefficients.xls' containing the figure number,
%   profile number, value of all the fitting coefficients and the fitting
%   error

% $ Author: Davide Marucci
% $ Creation Date: 06/05/2019
% $ Last Update Date: 07/05/2019
% $ Version: 1.5

%% Write data in FittingCoefficients.xls
MaxCoeffNr = 0;%Find maximum number of coeffients requested for all the profile fitting functions
for i = 1:length(fittingArray)
    for j = 1:length(fittingArray{i}.coeffFit)
        coeffNr = length(fittingArray{i}.coeffFit{j});
        if coeffNr > MaxCoeffNr
            MaxCoeffNr = coeffNr;
        end
    end
end
if MaxCoeffNr > 0
    fid = fopen('Output\1D\FittingCoefficients.xls','w');
    %Write file header
    fprintf(fid,'Figure Nr.\tProfile Nr.\t');
    for i = 1:MaxCoeffNr
        fprintf(fid,'C%d\t',i);
    end
    fprintf(fid,'Fitting error\n');
    
    %% Write coefficien values and error for each profile
    for i = 1:length(fittingArray)
        for j = 1:length(fittingArray{i}.coeffFit)
            fprintf(fid,'%d\t%d\t',i,fittingArray{i}.fittedProf(j));
            for ii = 1:MaxCoeffNr
                if ii <= length(fittingArray{i}.coeffFit{j})
                    fprintf(fid,'%1.6f\t',fittingArray{i}.coeffFit{j}(ii));
                else
                    fprintf(fid,'\t');
                end
            end
            fprintf(fid,'%1.6f\t',fittingArray{i}.errorFit(j));
            fprintf(fid,'\n');
        end
    end
    fclose(fid);
end