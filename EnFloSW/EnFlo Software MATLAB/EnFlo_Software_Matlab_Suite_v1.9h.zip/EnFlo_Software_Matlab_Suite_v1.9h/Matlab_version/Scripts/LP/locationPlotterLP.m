function errorMsg = locationPlotterLP(loc, in)
%locationPlotterLP    Produce a geometry plot from stl file and adds
%                     measuring points location
%   errorMsg = locationPlotterLP(loc, in)  outputs 
%   a location graph in which "loc" is 3column matrix containinig the location 
%   of the measuring points. "in" is a structure containg the options of the 
%   graph, nInputLine is the number of the figure.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 17/10/2020
% $ Version: 1.0a
%%
errorMsg = [];

%% Geometry loading and plot
if ~isempty(in.lGeometryFilename)
    TR = stlread(['Input\LP\Geometry\',in.lGeometryFilename]);
    v = TR.Points;
    f = TR.ConnectivityList;
    v(:,[1 2 3]) = v(:,[1 2 3]) + in.lGeometryTranslations';
    
    if in.lGeometryRotations(3) ~= 0
        v = rotateSTL(v,'z',in.lGeometryRotations(3));
    end
    if in.lGeometryRotations(2) ~= 0
        v = rotateSTL(v,'y',in.lGeometryRotations(2));
    end
    if in.lGeometryRotations(1) ~= 0
        v = rotateSTL(v,'x',in.lGeometryRotations(1));
    end
    
    field = 'faces';      value = {f};
    field2 = 'vertices';  value2 = {v};
    buildings = struct(field,value,field2,value2);
    
    patch(buildings,'FaceColor', in.lFaceColor, 'EdgeColor', in.lEdgeColor,'edgealpha',in.lEdgeTransparency)
    if in.lFaceTransparency < 1
        alpha(gca,in.lFaceTransparency)
    end
    
    clear f v n field field2 value value2 buildings
end

%% Plot Measuring points
if ~isempty(loc)
    plotHandle = plot3(loc(:,1),loc(:,2),loc(:,3));
    set(plotHandle,'linestyle','none','Marker',in.lMarkerType,...
        'MarkerSize',in.lMarkerSize,'color',in.lMarkerColor);
end
%% Plot reference point (if any)
if ~isempty(in.lRefPointCoord) && ~isempty(in.lRefPointSize) && ~isempty(in.lRefPointColor)
    scatter3(in.lRefPointCoord(1),in.lRefPointCoord(2),in.lRefPointCoord(3),...
        in.lRefPointSize,in.lRefPointColor,'p','filled','MarkerEdgeColor','k');
end

%% Plot reference velocity (if any)
if ~isempty(in.lRefArrowBaseCoord) && ~isempty(in.lRefArrowComponents) && ~isempty(in.lRefArrowSize) && ...
        ~isempty(in.lRefArrowColor)
    quiver3(in.lRefArrowBaseCoord(1),in.lRefArrowBaseCoord(2),in.lRefArrowBaseCoord(3),...
        in.lRefArrowComponents(1),in.lRefArrowComponents(2),in.lRefArrowComponents(3),...
        'MaxHeadSize',in.lRefArrowSize,'LineWidth',in.lRefArrowSize,'color',in.lRefArrowColor);
end