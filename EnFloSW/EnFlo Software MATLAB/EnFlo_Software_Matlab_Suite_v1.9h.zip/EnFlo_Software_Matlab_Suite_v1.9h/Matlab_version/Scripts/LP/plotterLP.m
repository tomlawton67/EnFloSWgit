function errorMsg = plotterLP
%plotterLP    Create 3D geometry graph and indicate the measuring points
%   errorMsg = plotterLP  creates one 3D geometry graph and indicating the 
%   measuring points, it can save it in separate file and/or visualise in an 
%   interactive window.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 17/10/2020
% $ Version: 1.0a
%%
close all; clc
%tic
errorMsg = [];
%Load input variables
[in, nInputLines, errorMsg] = inputVariablesloaderLP('Input\LP\InputLP.xls');
if ~isempty(errorMsg)
    return
end

%Load result files
[loc, errorMsg] = resultFileLoaderLP(nInputLines); %loc is an array of three column matrices containing the X, Y, Z coordinates for each measuring point                              
if ~isempty(errorMsg)
    return
end

%% Execute actions on each result file
%Set if the interactive window must show up
if in(1).fShowFigure == 0
    set(0,'DefaultFigureVisible','off');
else
    set(0,'DefaultFigureVisible','on');
end
figure(1);
hold on

for i = 1:nInputLines
    errorMsg = locationPlotterLP(loc{i}, in(i));
    if ~isempty(errorMsg)
        return
    end
end
hold off

% Set axis settings
xlabel(in(1).fAxisLabelX,'interpreter',in(1).fInterpreterText);
ylabel(in(1).fAxisLabelY,'interpreter',in(1).fInterpreterText);
zlabel(in(1).fAxisLabelZ,'interpreter',in(1).fInterpreterText)
title(in(1).fTitle,'interpreter',in(1).fInterpreterText);
% Set axis settings
if ~isempty(in(1).fAxisLimX)
    xlim([in(1).fAxisLimX(1) in(1).fAxisLimX(2)])
end
if ~isempty(in(1).fAxisLimY)
    ylim([in(1).fAxisLimY(1) in(1).fAxisLimY(2)])
end
if ~isempty(in(1).fAxisLimZ)
    zlim([in(1).fAxisLimZ(1) in(1).fAxisLimZ(2)])
end
set(gca,'XGrid',in(1).fGrid(1),'XMinorGrid',in(1).fGridMinor(1),'YGrid',in(1).fGrid(2),'YMinorGrid',in(1).fGridMinor(2),...
    'ZGrid',in(1).fGrid(3),'ZMinorGrid',in(1).fGridMinor(3),'FontSize',in(1).fFontSize,'box','on');

%Keep correct aspect ratio in graph
if in(1).fKeepAspectRatio == 1
    set(gca,'DataAspectRatio',[1 1 1])
end

view(in(1).fViewAngles(1),in(1).fViewAngles(2))
   
% Save single figure
if in(1).sSavePlot == 1
    singlePlotterLP(gcf,in(1))
end

%toc