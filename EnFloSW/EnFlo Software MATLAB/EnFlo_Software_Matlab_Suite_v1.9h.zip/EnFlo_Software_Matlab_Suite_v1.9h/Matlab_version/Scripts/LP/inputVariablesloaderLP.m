function [in, nInputLines, errorMsg] = inputVariablesloaderLP(inputFileName)
%inputVariablesloaderLP    load the input file variables    
%   [in, nInputLines, errorMsg] = inputVariablesloaderLP(inputFileName)  create 
%   an array "in" containg the input variables with the desired plot settings 
%   from an input file.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 23/05/2019
% $ Version: 1.0

%%
errorMsg = [];
[inputdata, fieldname, inputarray] = tsvread(inputFileName); %Read input file (inputdata is a matrix with only the numeric values, while text is shown as NaN
                                                           %fieldname is a string vector with the names taken from the first row of the input file)
                                                           %inputarray is an array with all the input entries considered as text
nInputLines = size(inputdata,1)-1;

%% Create variables structured as in from the file                                                           
in = cell(1,nInputLines);
inDefault = inputVarDefaultLP; %Load default values for input variables

%Check if all the required input variables have been created
fieldnameDefault = fieldnames(inDefault);
errorMsg = inputVariablesCheckerLP(fieldname, fieldnameDefault); 
if ~isempty(errorMsg)
    return
end

for j = 2:size(inputdata,1)
    for i = 1:length(fieldname)
        if ~iscell(inDefault.(fieldname{i})) %assign numerical quantity
            in{j-1}.(fieldname{i}) = inputdata(j,i);
        else %assign string quantity
            in{j-1}.(fieldname{i}) = inputarray{j,i};
            if strcmp(fieldname{i},'fAxisLimX') || strcmp(fieldname{i},'fAxisLimY') || ...
                    strcmp(fieldname{i},'fGrid') || strcmp(fieldname{i},'fGridMinor') || ...
                    strcmp(fieldname{i},'lGeometryTranslations') || strcmp(fieldname{i},'lGeometryRotations') || ...
                    strcmp(fieldname{i},'fAxisLimZ') || strcmp(fieldname{i},'fViewAngles') || strcmp(fieldname{i},'lRefPointCoord') || ...
                    strcmp(fieldname{i},'lRefArrowBaseCoord') || strcmp(fieldname{i},'lRefArrowComponents') || strcmp(fieldname{i},'fTickLabel')
                in{j-1}.(fieldname{i}) = eval(['[',in{j-1}.(fieldname{i}),']']);
            end
        end
    end
end

in = cell2mat(in);