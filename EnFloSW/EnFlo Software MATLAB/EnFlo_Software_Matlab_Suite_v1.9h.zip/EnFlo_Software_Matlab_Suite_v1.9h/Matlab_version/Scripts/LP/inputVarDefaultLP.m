function inDefault = inputVarDefaultLP
%inputVarDefaultLP    load the required variables names and format    
%   inDefault = inputVarDefaultLP  This function lists all the possible input 
%   entry which must be specified in the InputLP.xls file. When needed an 
%   explanation of the variable function is added. Only the variable name 
%   after the dot (hence excluding inDefault.) has to be indicated as header 
%   of the input file columns. The parenteses after the equal indicates if
%   the variable is expected to be a number [] or a string {}.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 23/05/2019
% $ Version: 1.0

%% Figure settings (To be specified only in the first line of the input file)
inDefault.lineNr = [];
inDefault.fAxisLabelX = {};
inDefault.fAxisLabelY = {};
inDefault.fAxisLabelZ = {};
inDefault.fTitle = {};
inDefault.fAxisLimX = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimY = {}; %[Min;Max] works only if both Min and Max are specified (if "-inf" or "inf" is set the limit will be the smallest or largest point)
inDefault.fAxisLimZ = {}; %[Min;Max] set z range in locationPlotter, works only if both Min and Max are specified
inDefault.fInterpreterText = {}; % ['latex','none']
inDefault.fShowFigure = []; %Show figure in interactive window [0,1]
inDefault.fKeepAspectRatio = []; %Keep costant scaling in figure axes [0,1]
inDefault.fGrid = {}; %[x-axis;y-axis;z-axis] Show axis grid in figure (0,1)
inDefault.fGridMinor = {}; %[x-axis;y-axis;z-axis] Show axis minor grid in figure (0,1)
inDefault.fTickLabel = {}; %[x-axis;y-axis;z-axis] Show axis tick labels (0,1)
inDefault.fFontSize = [];
inDefault.fViewAngles = {}; %(az;el) Set the viewing angles for the figure in degrees (azimuth and elevation angles)

%% Location plot settings (These settings are the only which can be specified for each input file line)
%These variables define the geometry properties. If the user wants to load different geometries, these properties have to be indicated for as much lines as the number of the geometries 
inDefault.lGeometryFilename = {}; %e.g. 'Geometry1.stl'. N.B. Geometry must be in STL format (binary or ASCII). If this variable is indicated in the line, also the other referring to the geometry must be indicated
inDefault.lGeometryTranslations = {};% (X;Y;Z) Translation to apply to the stl geometry to align its origin with the plot data origin
inDefault.lGeometryRotations = {};% (angleX;angleY;angleZ) angles (in degrees) to rotate to the stl geometry to align its axes with the plot data axes. The rotation will be done in the order around axis Z, Y and as last X
inDefault.lFaceColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lEdgeColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lFaceTransparency = []; %Face surface transparency value from 0 to 1 (where 0 is invisible and 1 solid)
inDefault.lEdgeTransparency = []; %Edge transparency value from 0 to 1 (where 0 is invisible and 1 solid)
%These variables refer to the measuring point markers
inDefault.lMarkerType = {};
inDefault.lMarkerColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal
inDefault.lMarkerSize = [];

%This variables set the reference point and arrow. Indicate only if a
%reference point and arrow are needed. Multiple points and arrow can be
%indicated (one for each line)
inDefault.lRefPointCoord = {}; %(x;y;z) Coordinates of reference point (e.g. source location) (leave blank if not needed)
inDefault.lRefPointColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.lRefPointSize = []; % e.g. 20 (leave blank if not needed)
inDefault.lRefArrowBaseCoord = {}; %(x;y;z) Coordinates of reference arrow base point (e.g. wind direction) (leave blank if not needed)
inDefault.lRefArrowComponents = {}; %(x;y;z) Lengths of reference arrow in each direction (leave blank if not needed)
inDefault.lRefArrowColor = {}; %['r','g','b','c','m','y','k','w'] or hexadecimal (leave blank if not needed)
inDefault.lRefArrowSize = []; % (e.g. 2) Specify the arrow line width and head size (they have to be the same) (leave blank if not needed)

%% Singleplotter settings (To be specified only in the first line of the input file)
inDefault.sSavePlot = []; % Save single plot [0,1]
inDefault.sFormatFig = {}; % ['fig','png','jpeg','bmp','pdf','meta',etc.]
inDefault.sFigRenderer = {}; % ['opengl','painters']
inDefault.sLeftEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sBottomEdge = []; %in cm (This value is ignored when saving a figure to a nonpage format, such as a PNG or EPS format.)
inDefault.sPlotHeight = []; %in cm
inDefault.sPlotWidth = []; %in cm