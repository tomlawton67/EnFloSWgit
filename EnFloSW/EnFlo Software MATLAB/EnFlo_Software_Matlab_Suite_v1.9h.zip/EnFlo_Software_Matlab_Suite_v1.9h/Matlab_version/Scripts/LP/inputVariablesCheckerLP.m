function errorMsg = inputVariablesCheckerLP(fieldname, fieldnameDefault)
%inputVariablesCheckerLP    Check if all the required input variables have been assigned  
%   errorMsg = inputVariablesCheckerLP(fieldname, fieldnameDefault)  compares 
%   the input variables "fieldname" with "fieldnameDefault" and outputs an
%   eror message if one or more are missing

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 23/05/2019
% $ Version: 1.0

%%
errorMsg = [];
missingFieldList = [];
idxList = [];
for i = 1:length(fieldnameDefault)
    idx = find(strcmp(fieldname, fieldnameDefault{i}));
    if isempty(idx)
        missingFieldList(end+1) = i;
    else
        idxList(end+1) = idx;
    end
end
clear idx
if ~isempty(missingFieldList)
    errorMsg = 'The following required variables are not present in the InputLP.xls file: ';
    for i = 1:length(missingFieldList)
        errorMsg = [errorMsg, fieldnameDefault{missingFieldList(i)},' '];
    end
    return
end

%%
idxList = [];
for i = 1:length(fieldname)
    idx = find(strcmp(fieldnameDefault, fieldname{i}));
    if isempty(idx)
        missingFieldList(end+1) = i;
    else
        idxList(end+1) = idx;
    end
end
clear idx
if ~isempty(missingFieldList)
    errorMsg = 'The following variables present in InputLP.xls file do not correspond to any requested variable: ';
    for i = 1:length(missingFieldList)
        errorMsg = [errorMsg, fieldname{missingFieldList(i)},' '];
    end
    return
end