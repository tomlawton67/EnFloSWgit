function [loc, errorMsg] = resultFileLoaderLP(nResults)
%resultFileLoaderLP    load the input file variables    
%   [loc, errorMsg] = resultFileLoaderLP(nResults)  Load 
%   the result files (one for each graph) and produce an array, "loc", with 
%   three column matrices with X,Y,Z measuring point locations.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 23/05/2019
% $ Version: 1.0

%%
errorMsg = [];
ResultData = cell(1,nResults);
loc = cell(1,nResults);

for i = 1:nResults   
    if isfile(['Input\LP\Data\Data',num2str(i),'.xls'])
        ResultData{i} = tsvread(['Input\LP\Data\Data',num2str(i),'.xls']); %Import data from Result files with tsvread
        loc{i}(:,[1 2 3]) = ResultData{i}(5:end,[1 2 3]); %X, Y, Z measuring point coordinates
        if size(ResultData{i},2) ~= 3
            errorMsg = ['The number of columns in Input\LP\Data\Data', num2str(i),'.xls must be 3'];
            return
        end
    else
        loc{i} = [];
    end
end