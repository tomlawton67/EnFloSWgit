function singlePlotterLP(fig, in)
%singlePlotterLP    Save a single figure in a file    
%   singlePlotterLP(fig, in)  saves a figure "fig" opened 
%   in Matlab environment in the desired format. "in" is an structure 
%   with plotting options for the figure.

% $ Author: Davide Marucci
% $ Creation Date: 23/05/2019
% $ Last Update Date: 23/05/2019
% $ Version: 1.0
%%
fig.PaperUnits = 'centimeters';
fig.PaperPosition = [in.sLeftEdge in.sBottomEdge in.sPlotWidth in.sPlotHeight];
fig.Renderer = in.sFigRenderer;
set(groot,'defaultFigurePaperPositionMode','manual')
saveas(fig, 'Output\LP\SingleImage', in.sFormatFig);