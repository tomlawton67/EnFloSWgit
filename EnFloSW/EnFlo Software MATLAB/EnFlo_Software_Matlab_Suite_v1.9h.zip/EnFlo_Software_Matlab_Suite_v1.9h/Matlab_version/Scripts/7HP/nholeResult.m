function [U, V, W, minerr] = nholeResult(pitingrid, yawingrid, Pingrid, calCPogrid, calCPsgrid, P, rho)
% PART 2 of 2 nholeCalib + nHoleResult
% This function converts n-hole probe pressure data into dimensional 
% velocity components using an n-dimensional hypercube interpolation and 
% look-up technique. 
%
% SYNTAX: 
%   
% [U, V, W, error] = ...
%    sevenb(calibration_pitch, calibration_yaw, calibration_pressures, calibration_P_{tot}, ...
%    calibration_P_{stat}, measurement_pressures, measurement_P_{tot}, measurement_P_{stat}, ...
%    measurement_density, desired_resolution)
%
% where, if there were m calibration points, n measurement points and q pressure holes, 
% 
%  [U, V, W]: Dimensional velocity components (m/s) along x, y and z (nx1) 
% 
%  error: Quantification of error between measurement and calibration data (nx1) 
% 
%  calibration_pitch, calibration_yaw: Arrays of pitch and yaw angles (�) used  for calibration (mx1) 
% 
%  calibration_pressures: Pressures (Pa) measured at each of the calibration points (mxq) 
% 
%  calibration_P_{tot}: Total pressures (Pa) recorded during calibration (mx1) 
% 
%  calibration_P_{stat}: Static pressures (Pa) recorded during calbration (mx1) 
% 
%  measurement_pressures: Pressures measured (Pa) at each of the measurement points (nxq) 
% 
%  measurement_P_{tot}: Total pressures (Pa) recorded during measurement (nx1) 
% 
%  measurement_P_{stat}: Static pressures (Pa) recorded during measurement (nx1) 
% 
%  measurement_density: Fluid density (kg/m^3) during measurement 
% 
%  desired_resolution: Resulting flow angles will be precise to within 
%  ( max(calibration angle) - min(calibration angle) )/resolution

warning off

% Now, we can use that fine-mesh interpolated structured calibration data
% to convert the experimental measurements.

[nx, np] = size(P);

for ix = 1:nx
    
    outPmax(ix) = max(P(ix,:));         % Approximate stagnation pressure
    outPbar(ix) = min(P(ix,:));         % Approximate static pressure
    
        Perr = zeros(size(yawingrid));
    
% At each data point, work out a total error between the pressures recorded 
% and the pressures at each point in the fine calibration grid.
   
    for i = 1:np
       Perr = Perr + ((outPmax(ix)-P(ix,i))./(outPmax(ix)-outPbar(ix))-Pingrid{i}).^2;
    end
    
% The grid location at which the error is minimum represents the best guess 
% at what the flow angularity is at the point in question.
    
    mini = find(Perr == min(min(Perr)));
    minerr(ix) = (Perr(mini)./(np*outPmax(ix))).^0.5;
    
    outpit(ix) = pitingrid(mini);
    outyaw(ix) = yawingrid(mini);
    outCPo(ix) = calCPogrid(mini);
    outCPs(ix) = calCPsgrid(mini);
        
end

% Compute velocity magnitude

outU = (2*(outPmax-outPbar).*(outCPs-outCPo+1)./rho').^0.5;

% Resolve velocity into components
    
CosAlpha = cosd(outyaw);
UcosAlpha = outU.* CosAlpha;
U = UcosAlpha.* cosd(outpit);
V = - UcosAlpha.* sind(outpit);
W = outU.* sind(outyaw);

U=U';
V=V';
W=W';