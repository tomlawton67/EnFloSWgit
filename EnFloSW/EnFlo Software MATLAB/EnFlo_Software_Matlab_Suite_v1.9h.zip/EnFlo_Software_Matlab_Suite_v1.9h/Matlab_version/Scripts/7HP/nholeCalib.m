function [pitingrid, yawingrid, Pingrid, calCPogrid, calCPsgrid] = nholeCalib(pitin, yawin, Pin, Ptotin, Pstatin, ngrid)
% PART 1 of 2 nholeCalib + nHoleResult
% This function converts n-hole probe pressure data into dimensional 
% velocity components using an n-dimensional hypercube interpolation and 
% look-up technique. 
%
% SYNTAX: 
%   
% [U, V, W, error] = ...
%    sevenb(calibration_pitch, calibration_yaw, calibration_pressures, calibration_P_{tot}, ...
%    calibration_P_{stat}, measurement_pressures, measurement_P_{tot}, measurement_P_{stat}, ...
%    measurement_density, desired_resolution)
%
% where, if there were m calibration points, n measurement points and q pressure holes, 
% 
%  [U, V, W]: Dimensional velocity components (m/s) along x, y and z (nx1) 
% 
%  error: Quantification of error between measurement and calibration data (nx1) 
% 
%  calibration_pitch, calibration_yaw: Arrays of pitch and yaw angles (�) used  for calibration (mx1) 
% 
%  calibration_pressures: Pressures (Pa) measured at each of the calibration points (mxq) 
% 
%  calibration_P_{tot}: Total pressures (Pa) recorded during calibration (mx1) 
% 
%  calibration_P_{stat}: Static pressures (Pa) recorded during calbration (mx1) 
% 
%  measurement_pressures: Pressures measured (Pa) at each of the measurement points (nxq) 
% 
%  measurement_P_{tot}: Total pressures (Pa) recorded during measurement (nx1) 
% 
%  measurement_P_{stat}: Static pressures (Pa) recorded during measurement (nx1) 
% 
%  measurement_density: Fluid density (kg/m^3) during measurement 
% 
%  desired_resolution: Resulting flow angles will be precise to within 
%  ( max(calibration angle) - min(calibration angle) )/resolution

warning off

% Produce a set of non-repeating structured arrays for calibration pitch and yaw 

pitingridc = linspace(min(pitin), max(pitin), numel(unique(pitin))); 
yawingridc = linspace(min(yawin), max(yawin), numel(unique(yawin))); 
[pitingridc, yawingridc] = meshgrid(pitingridc,yawingridc);

% Produce a set of fine-resolution arrays for pitch and yaw

pitingrid = linspace(min(pitin), max(pitin), ngrid); 
yawingrid = linspace(min(yawin), max(yawin), ngrid); 
[pitingrid, yawingrid] = meshgrid(pitingrid,yawingrid);

[ncal, np] = size(Pin);

Pmax = max(Pin')';      % Approximated stagnation pressure
Pbar = min(Pin')';      % Approximated static pressure

% Interpolate pressure data from calibration input array onto structured grid

for ip = 1:np
    
% First, use GRIDDATA to turn unstructured calibration pressure array into 
% a structured data grid. 
    
    Pingrid{ip} = griddata(pitin, yawin, (Pmax-Pin(:,ip))./(Pmax-Pbar), pitingrid, yawingrid, 'cubic');
    
end

% Repeat the process for static and stagnation pressure coefficients.

calCPo = (Pmax-Ptotin)./(Pmax-Pbar);
calCPogrid =  griddata(pitin, yawin, calCPo, pitingrid, yawingrid, 'cubic');

calCPs = (Pbar-Pstatin)./(Pmax-Pbar);
calCPsgrid = griddata(pitin, yawin, calCPs, pitingrid, yawingrid, 'cubic');