function [errorMsg, CalibNameList, calib] = sevenHoleProbeCalib(calibName, CalibNameList, calib, ngrid, OUTdecimalPlaces)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SevenHoleProbCalib %%%%%%%%%%%%%%%%%%%%%%%%%%
% This function post-processes pressure data from the seven-hole probe and
% outputs three-component velocity data.
% INPUT:  - [calibName.xls], PressureResultsFile.xls
% OUTPUT: - VelocityResultsFile.xls 
% Once opened the function checks if the calibName is already in the list, 
% if not it loads the calibration file, computes the calibration data and 
% stores it in the list. It then loads the pressure and uses the calibration 
% to compute the ceclocities and store them in a file.

% $ Author: Davide Marucci
% $ Creation Date: 2018
% $ Last Update Date: 21/05/2019
% $ Version: 1.6
%%
HeaderArray = {'Time (s)', 'U (m/s)', 'V (m/s)', 'W (m/s)', 'minerr'};
errorMsg = [];

%% IMPORT CALIBRATION DATA
[oldCalib, oldCalibLoc] = ismember(calibName,CalibNameList); %Check if string is already in memory and if yes give location
if oldCalib == 1
    i1 = oldCalibLoc; %Location of calib data in calibration array
else %If it is not in memory add string to list and start calibration routine
    i1 = find(cellfun(@isempty,CalibNameList()),1); %Find the first empty cell in CalibNameList
    if isempty(i1) %If all the preallocated cell in CalibNameList are full, create a new cell
        CalibNameList{end+1} = calibName;
        i1 = length(CalibNameList);
    end       
    CalibNameList{i1} = calibName;
    CalibData = tsvread(['Input\7HP\',calibName]);
    yawin = CalibData(5:end,1);
    pitin = CalibData(5:end,2);
    Pin(:,1:7) = CalibData(5:end,3:9);
    Pstatin = CalibData(5:end,10);
    Ptotin = CalibData(5:end,11);
    [calib{i1}.pitingrid, calib{i1}.yawingrid, calib{i1}.Pingrid, calib{i1}.calCPogrid, ...
        calib{i1}.calCPsgrid] = nholeCalib(pitin, yawin, Pin, Ptotin, Pstatin, ngrid);
    clear CalibData Pin Pstatin Ptotin pitin yawin
end

%% PRESSURE TO VELOCITY CONVERSION: OUT = [time, U, V, W, minerr]

ResultData = tsvread('Input\7HP\PressureResultsFile.xls');
time = ResultData(5:end,1);
P(:,1:7) = ResultData(5:end,2:8);
rho = ResultData(5:end,9);

OUT(:,1) = time;
[OUT(:,2),OUT(:,3),OUT(:,4),OUT(:,5)] = nholeResult(calib{i1}.pitingrid, ...
    calib{i1}.yawingrid, calib{i1}.Pingrid, calib{i1}.calCPogrid, calib{i1}.calCPsgrid, P, rho);

%% EXPORT DATA
fid = fopen('Output\7HP\VelocityResultsFile.xls','w');
for k=1:5
    fprintf(fid,'%s\t',HeaderArray{k});
end
fprintf(fid,'\n');
fclose(fid);
dlmwrite('Output\7HP\VelocityResultsFile.xls',OUT,'-append','delimiter','\t','precision',['%.',num2str(OUTdecimalPlaces),'f']);
