function waitingWhileisVisible
%waitingWhileisVisible    Waits ina loop that all the visible figures are 
%                            closed before continuing 
%   waitingWhileisVisible  no input/output

% $ Author: Davide Marucci
% $ Creation Date: 03/05/2020
% $ Last Update Date: 04/09/2020
% $ Version: 1.9a

%%
while 1
    figHandles = findall(groot,'Type', 'figure');
    if ~isempty(figHandles)
        figVisibleCheck = strcmp(get(figHandles,'visible'),'on');
        if max(figVisibleCheck) == 0
            break
        else
            pause(1)
        end
    else
        break
    end
end