function [ax, h] = multiPlotMainTitle(text, interpreter, fontSize)
%multiPlotMainTitle    Center a title over a group of subplots
%   [ax, h] = multiPlotMainTitle(text, in)  returns a handle to the title 
%   and the handle to an axis.
%   ax = subtitle(text, in)  returns a handle to the axis only.
%   "Text" is the title text, "interpreter" is the text interpreter (either 
%   'none' or 'latex'), "fontsize" is the text dimension.

% $ Author: unknown (downloaded from the internet)
% $ Creation Date: 12/04/2016
% $ Last Update Date: 05/04/2019
% $ Version: 1.2
%%

ax=axes('Units','Normal','Position',[.075 .075 .85 .89],'Visible','off');
set(get(ax,'Title'),'Visible','on')
title(text,'interpreter',interpreter,'fontsize',fontSize);
if (nargout < 2)
    return
end
h=get(ax,'Title');