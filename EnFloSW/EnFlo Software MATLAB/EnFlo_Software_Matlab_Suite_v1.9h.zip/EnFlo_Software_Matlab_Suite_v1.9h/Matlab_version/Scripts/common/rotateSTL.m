function tri = rotateSTL(tri,ax1,theta1)
%rotateSTL    Apply a rotation of an angle theta1 around axis ax1
%   tri = rotateSTL(tri,ax1,theta1)  outputs a rotated
%   geometry "tri" with the rotation of angle theta1. It applies also to
%   other vectorial quantities (e.g. velocity components)

% $ Author: Davide Marucci
% $ Creation Date: 09/09/2019
% $ Last Update Date: 10/05/2019
% $ Version: 1.5

%%
if ax1 == 'x'
    rotmat = [1, 0, 0; 0, cosd(theta1),-sind(theta1); 0, sind(theta1),cosd(theta1)];
elseif ax1 == 'y'
    rotmat = [cosd(theta1), 0 , sind(theta1); 0,1,0; -sind(theta1) 0, cosd(theta1)];
elseif ax1 == 'z'
    rotmat = [cosd(theta1), -sind(theta1), 0; sind(theta1), cosd(theta1),0; 0, 0,1];
end

tri(:,1:3) = tri(:,1:3) * rotmat;
if size(tri,2) >= 9
    tri(:,4:6) = tri(:,4:6) * rotmat;
    tri(:,7:9) = tri(:,7:9) * rotmat;
end
