
%%%%%%%%%%%%%%%%%%%%%%%% EnFlo Software Matlab Suite %%%%%%%%%%%%%%%%%%%%%%
% The suite is created to cooperate with Enflo Software. A
% communication by means of TCP/IP is created, in which this
% programme is run as server. This programme manage the communication with
% EnFlo Software and call the subfunction to:
% - Create 1D plots
% - Create 2D contouplots
% - Create location plots
% - postprocess seven-hole probe data.

% $ Author: Davide Marucci
% $ Creation Date: 02/05/2019
% $ Last Update Date: 07/03/2021
% $ Version: 1.9g
%%
clear all; clc;  %Comment this line before compiling
%% Load input settings
addpath('Scripts\common','Scripts\1D','Scripts\2D','Scripts\LP','Scripts\7HP'); %Comment this line before compiling
inputSettings = tsvread('EnFloSoftwareMatlabSuiteSettings.xls');
commPort = inputSettings(5,1);
stringLength = inputSettings(5,2);
ngrid7HP = inputSettings(5,3);
OUTdecimalPlaces7HP = inputSettings(5,4);
clear inputSettings

if ~isfile('ErrorLog.txt')
    fid = fopen('ErrorLog.txt','w');
    fprintf(fid,'-*-*-* ERROR LOG FILE EnFlo Software Matlab Suite *-*-*-\r\n\r\n');
    fclose(fid);
end

%%
comm = tcpip('0.0.0.0', commPort, 'NetworkRole', 'server','Timeout', 300); %Open a connection. This will not return until a connection is received.
clear commPort
ProgrammeList = {'plotter1D','plotter2D','locationPlotter','SevenHoleProbeCalib'};
CalibNameList7HP = cell(20,1); calibArray7HP = cell(20,1); %Allocate 20 spaces for calibration files, if they are going to be more other space will be allocated later
for i=1:20
    CalibNameList7HP{i} = '';
end
while 1
    errorMsg = [];
    warningMsg = {};
    fopen(comm);%This will not return until a connection is received.
    inputStr = fread(comm,[1 stringLength]); %InputStr is a fixed stringLength char string in which the first 2 char are the funcSel and the other are free for instructions (separated by ;)
    inputStr = char(inputStr);
    
    %Split inputStr
    funcSel = str2double(inputStr([1 2]));
    semiColLoc = strfind(inputStr,';');
    semiColLoc(end+1) = strlength(inputStr)+1;
    inputArg = cell((length(semiColLoc)-1),1);
    for i = 1:(length(semiColLoc)-1)
        inputArg{i} = inputStr((semiColLoc(i)+1):(semiColLoc(i+1)-1));
    end
    
    switch funcSel
        case 1
            close all
            errorMsg = plotter1D;
        case 2
            close all
            [errorMsg, warningMsg] = plotter2D;
        case 3
            close all
            errorMsg = plotterLP;
        case 4
            [errorMsg, CalibNameList7HP, calibArray7HP] = sevenHoleProbeCalib(inputArg{1}, ...
                CalibNameList7HP, calibArray7HP, ngrid7HP, OUTdecimalPlaces7HP); %inputArg{1} is the calibration file name
    end
    
    %%  Output message generation
    outMsg = inputStr(1:3);
    if isempty(errorMsg) && isempty(warningMsg) %If no error or warnings occurred
        for i = 1:(stringLength-3)
            outMsg = sprintf('%s%s',outMsg,' ');
        end
        fwrite(comm,outMsg);
    elseif ~isempty(errorMsg) %If an error occurred
        % Write error file
        date = clock;
        fid = fopen('ErrorLog.txt','a');
        fprintf(fid,'%02.0f/%02.0f/%02.0f %02.0f:%02.0f:%04.1f',date);
        fprintf(fid,' - %s: %s\r\n',ProgrammeList{funcSel},errorMsg);
        fclose(fid);
        
        outMsg = [outMsg,errorMsg,';'];
        if strlength(outMsg) < stringLength
            for i=1:(stringLength-strlength(outMsg))
                outMsg = sprintf('%s%s',outMsg,' ');
            end
        end
        fwrite(comm,outMsg(1:stringLength));
    else %If one or more warnings occurred
        % Write error file
        date = clock;
        fid = fopen('ErrorLog.txt','a');
        for ii = 1:length(warningMsg)            
            fprintf(fid,'%02.0f/%02.0f/%02.0f %02.0f:%02.0f:%04.1f',date);
            fprintf(fid,' - %s: %s\r\n',ProgrammeList{funcSel},warningMsg{ii});
            outMsg = [outMsg,warningMsg{ii},';'];
        end
        fclose(fid);
               
        if strlength(outMsg) < stringLength
            for i=1:(stringLength-strlength(outMsg))
                outMsg = sprintf('%s%s',outMsg,' ');
            end
        end
        fwrite(comm,outMsg(1:stringLength));
    end
    clear date funcSel i fid inputArg inputStr outMsg semiColLoc ans
    fclose(comm);
    waitingWhileisVisible %Check if any visible interactive window is
    %still open. If it is open, wait for it to be manually closed 
   
end